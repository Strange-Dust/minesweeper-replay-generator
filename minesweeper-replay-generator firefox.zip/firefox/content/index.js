"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/utils/browser.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill(), 1);
  var browser_default = import_webextension_polyfill.default;

  // src/lib/recording/mouseTracker.ts
  var pixelRound = navigator.userAgent.includes("Firefox") ? Math.floor : Math.round;
  var MouseTracker = class {
    boardElement;
    squareSize;
    onEvent;
    moveThrottleMs;
    keyboardMouse;
    borderElement;
    gameStartTime = 0;
    isTracking = false;
    lastMoveTime = 0;
    /** Last known mouse position relative to the board (for keyboard events) */
    lastMouseX = 0;
    lastMouseY = 0;
    /**
     * Which mouse button (0=left, 1=middle, 2=right) was pressed in the
     * border area, or -1 if none.  Used to synthesise a press event when
     * the cursor subsequently enters the board with the button still held.
     */
    borderPressButton = -1;
    /** Whether shift was held during the border press (for sc detection). */
    borderPressShift = false;
    // Bound handlers (for proper removal)
    handleMouseDown;
    handleMouseUp;
    handleMouseMove;
    handleKeyDown;
    handleKeyUp;
    handleBorderMouseDown;
    handleBorderMouseUp;
    handleBoardMouseEnter;
    constructor(config) {
      this.boardElement = config.boardElement;
      this.squareSize = config.squareSize;
      this.onEvent = config.onEvent;
      this.moveThrottleMs = config.moveThrottleMs ?? 0;
      this.keyboardMouse = config.keyboardMouse;
      this.borderElement = config.borderElement;
      this.handleMouseDown = this.onMouseDown.bind(this);
      this.handleMouseUp = this.onMouseUp.bind(this);
      this.handleMouseMove = this.onMouseMove.bind(this);
      this.handleKeyDown = this.onKeyDown.bind(this);
      this.handleKeyUp = this.onKeyUp.bind(this);
      this.handleBorderMouseDown = this.onBorderMouseDown.bind(this);
      this.handleBorderMouseUp = this.onBorderMouseUp.bind(this);
      this.handleBoardMouseEnter = this.onBoardMouseEnter.bind(this);
    }
    /**
     * Start tracking mouse events.
     * @param gameStartTime - performance.now() timestamp of game start
     */
    start(gameStartTime) {
      if (this.isTracking) return;
      this.gameStartTime = gameStartTime;
      this.isTracking = true;
      this.lastMoveTime = 0;
      this.boardElement.addEventListener("mousedown", this.handleMouseDown, { passive: true });
      this.boardElement.addEventListener("mouseup", this.handleMouseUp, { passive: true });
      this.boardElement.addEventListener("mousemove", this.handleMouseMove, { passive: true });
      if (this.keyboardMouse?.enabled) {
        document.addEventListener("keydown", this.handleKeyDown, { passive: true });
        document.addEventListener("keyup", this.handleKeyUp, { passive: true });
      }
      if (this.borderElement) {
        this.borderPressButton = -1;
        this.borderElement.addEventListener("mousedown", this.handleBorderMouseDown, { passive: true });
        document.addEventListener("mouseup", this.handleBorderMouseUp, { passive: true });
        this.boardElement.addEventListener("mouseenter", this.handleBoardMouseEnter, { passive: true });
      }
    }
    /**
     * Stop tracking mouse events and remove all listeners.
     */
    stop() {
      if (!this.isTracking) return;
      this.isTracking = false;
      this.boardElement.removeEventListener("mousedown", this.handleMouseDown);
      this.boardElement.removeEventListener("mouseup", this.handleMouseUp);
      this.boardElement.removeEventListener("mousemove", this.handleMouseMove);
      document.removeEventListener("keydown", this.handleKeyDown);
      document.removeEventListener("keyup", this.handleKeyUp);
      if (this.borderElement) {
        this.borderElement.removeEventListener("mousedown", this.handleBorderMouseDown);
        document.removeEventListener("mouseup", this.handleBorderMouseUp);
        this.boardElement.removeEventListener("mouseenter", this.handleBoardMouseEnter);
        this.borderPressButton = -1;
      }
    }
    /**
     * Update the board element reference (e.g., if the DOM changes).
     */
    updateBoardElement(element) {
      const wasTracking = this.isTracking;
      if (wasTracking) this.stop();
      this.boardElement = element;
      if (wasTracking) this.start(this.gameStartTime);
    }
    /**
     * Update the game start time without removing/re-adding event listeners.
     *
     * Used by the recorder when transitioning from 'ready' to 'recording'.
     * Avoids the stop()/start() cycle which briefly detaches all listeners
     * — a window during which rapid back-to-back events could be lost.
     */
    setGameStartTime(gameStartTime) {
      this.gameStartTime = gameStartTime;
    }
    // --------------------------------------------------------------------------
    // Internal event handlers
    // --------------------------------------------------------------------------
    onMouseDown(domEvent) {
      if (!this.isTracking) return;
      this.updateMousePosition(domEvent);
      let code;
      switch (domEvent.button) {
        case 0:
          code = domEvent.shiftKey ? "sc" : "lc";
          break;
        case 1:
          code = "mc";
          break;
        case 2:
          code = "rc";
          break;
        default:
          return;
      }
      this.emitEvent(code, domEvent);
    }
    onMouseUp(domEvent) {
      if (!this.isTracking) return;
      let code;
      switch (domEvent.button) {
        case 0:
          code = "lr";
          break;
        case 1:
          code = "mr";
          break;
        case 2:
          code = "rr";
          break;
        default:
          return;
      }
      this.emitEvent(code, domEvent);
    }
    onMouseMove(domEvent) {
      if (!this.isTracking) return;
      this.updateMousePosition(domEvent);
      if (this.moveThrottleMs > 0) {
        const now = performance.now();
        if (now - this.lastMoveTime < this.moveThrottleMs) return;
        this.lastMoveTime = now;
      }
      this.emitEvent("mv", domEvent);
    }
    // --------------------------------------------------------------------------
    // Border-click handlers
    // --------------------------------------------------------------------------
    /**
     * Track mousedown events on the border/wrapper element.
     *
     * On minesweeper.online the #game wrapper includes a visible border
     * around #AreaBlock.  Clicking this border and dragging into the board
     * is treated by the site as a valid click — cells depress and reveal
     * on release just like a normal click.  However, no mousedown fires on
     * #AreaBlock itself, so we would miss the press event.
     *
     * We only record the button here; the actual press event is synthesised
     * in onBoardMouseEnter when the cursor crosses into the board.
     *
     * Clicks that originate on the board itself are ignored (those are
     * already handled by onMouseDown).  Clicks from outside #game entirely
     * are never seen here, which is intentional — the site's behaviour for
     * those is inconsistent and we don't attempt to handle them.
     */
    onBorderMouseDown(domEvent) {
      if (!this.isTracking) return;
      if (this.boardElement.contains(domEvent.target)) return;
      this.borderPressButton = domEvent.button;
      this.borderPressShift = domEvent.shiftKey;
    }
    /**
     * Clear border-press tracking on any mouseup (listens on document so
     * we catch releases regardless of where the cursor is).
     */
    onBorderMouseUp(_domEvent) {
      this.borderPressButton = -1;
    }
    /**
     * When the cursor enters the board with a border-pressed button held,
     * synthesise the press event at the board entry point.
     *
     * The mouseenter event's clientX/clientY give us the exact position
     * where the cursor crossed the board boundary, which is the correct
     * coordinate for the synthesised press.
     */
    onBoardMouseEnter(domEvent) {
      if (!this.isTracking) return;
      if (this.borderPressButton < 0) return;
      let code;
      switch (this.borderPressButton) {
        case 0:
          code = this.borderPressShift || domEvent.shiftKey ? "sc" : "lc";
          break;
        case 1:
          code = "mc";
          break;
        case 2:
          code = "rc";
          break;
        default:
          this.borderPressButton = -1;
          return;
      }
      this.borderPressButton = -1;
      this.borderPressShift = false;
      this.emitEvent(code, domEvent);
    }
    // --------------------------------------------------------------------------
    // Keyboard-as-mouse handlers
    // --------------------------------------------------------------------------
    /**
     * Translate a keydown event to a mouse click event if the key matches
     * the configured keyboard-as-mouse keys. Uses the last known mouse
     * position to determine board coordinates.
     */
    onKeyDown(domEvent) {
      if (!this.isTracking || !this.keyboardMouse?.enabled) return;
      if (domEvent.repeat) return;
      const code = this.keyCodeToMouseCode(domEvent.keyCode, true);
      if (!code) return;
      this.emitKeyboardEvent(code, domEvent);
    }
    /**
     * Translate a keyup event to a mouse release event.
     */
    onKeyUp(domEvent) {
      if (!this.isTracking || !this.keyboardMouse?.enabled) return;
      const code = this.keyCodeToMouseCode(domEvent.keyCode, false);
      if (!code) return;
      this.emitKeyboardEvent(code, domEvent);
    }
    /**
     * Map a keyboard key code to a mouse event code based on configuration.
     *
     * If the same key is mapped to both left and right, it acts as left click
     * (matching minesweeper.online behavior where a single key maps to one action).
     */
    keyCodeToMouseCode(keyCode, isDown) {
      if (!this.keyboardMouse) return null;
      const isLeft = keyCode === this.keyboardMouse.leftKeyCode;
      const isRight = keyCode === this.keyboardMouse.rightKeyCode;
      if (isLeft && isRight) {
        return isDown ? "lc" : "lr";
      }
      if (isLeft) return isDown ? "lc" : "lr";
      if (isRight) return isDown ? "rc" : "rr";
      return null;
    }
    // --------------------------------------------------------------------------
    // Helpers
    // --------------------------------------------------------------------------
    /**
     * Convert a DOM MouseEvent to a RecordedMouseEvent and emit it.
     * Uses domEvent.timeStamp (the actual moment the browser detected the
     * input) rather than performance.now() (when the JS callback runs).
     * This eliminates event-loop latency from the recorded timestamps.
     */
    emitEvent(code, domEvent) {
      const boardRect = this.boardElement.getBoundingClientRect();
      const x = pixelRound(domEvent.clientX - boardRect.left);
      const y = pixelRound(domEvent.clientY - boardRect.top);
      const timeMs = Math.max(0, Math.round(domEvent.timeStamp - this.gameStartTime));
      const recorded = {
        type: "mouse",
        timeMs,
        event: code,
        x,
        y,
        rawTimestamp: domEvent.timeStamp
      };
      this.onEvent(recorded);
    }
    /**
     * Update the last known mouse position from a mouse event.
     * Called on every mousemove (before throttling) so keyboard events
     * always have an up-to-date position.
     */
    updateMousePosition(domEvent) {
      const boardRect = this.boardElement.getBoundingClientRect();
      this.lastMouseX = pixelRound(domEvent.clientX - boardRect.left);
      this.lastMouseY = pixelRound(domEvent.clientY - boardRect.top);
    }
    /**
     * Emit a RecordedMouseEvent from a keyboard event using the last
     * known mouse position on the board.
     * Uses domEvent.timeStamp for precise timing (same as emitEvent).
     */
    emitKeyboardEvent(code, domEvent) {
      const timeMs = Math.max(0, Math.round(domEvent.timeStamp - this.gameStartTime));
      const recorded = {
        type: "mouse",
        timeMs,
        event: code,
        x: this.lastMouseX,
        y: this.lastMouseY,
        rawTimestamp: domEvent.timeStamp
      };
      this.onEvent(recorded);
    }
  };

  // src/lib/recording/recorder.ts
  var GameRecorder = class {
    state = "idle";
    board;
    minePositions;
    metadata;
    onStateChange;
    mouseTracker;
    events = [];
    /** Events buffered before the game officially starts (press before release) */
    pendingEvents = [];
    /** Whether we've seen a press event and are waiting for the release */
    waitingForRelease = false;
    gameStartTime = 0;
    gameEndTime = 0;
    result = "unknown";
    /** Position of the last emitted event — used to suppress redundant moves
     *  immediately after the first click rebase. */
    lastEmittedX = -1;
    lastEmittedY = -1;
    /**
     * When true, the recorder buffers mouse events instead of processing them.
     * Used after finishAndReset() to prevent a phantom game from starting
     * while the board still shows the end-game state (mines revealed, face
     * showing win/lose). Call unfreeze() when the board actually resets —
     * buffered events are replayed so the first click is captured.
     */
    frozen = false;
    /** Events captured while frozen — replayed on unfreeze(). */
    frozenBuffer = [];
    constructor(config) {
      this.board = config.board;
      this.minePositions = config.minePositions ?? [];
      this.metadata = config.metadata;
      this.onStateChange = config.onStateChange;
      this.mouseTracker = new MouseTracker({
        ...config.mouseTrackerConfig,
        onEvent: (event) => this.onMouseEvent(event)
      });
    }
    // --------------------------------------------------------------------------
    // Public API
    // --------------------------------------------------------------------------
    /**
     * Get the current recording state.
     */
    getState() {
      return this.state;
    }
    /**
     * Get the number of events recorded so far.
     */
    getEventCount() {
      return this.events.length;
    }
    /**
     * Get elapsed time in ms (0 if not yet recording).
     */
    getElapsedMs() {
      if (this.state === "recording") {
        return Math.round(performance.now() - this.gameStartTime);
      }
      if (this.state === "finished") {
        return this.gameEndTime;
      }
      return 0;
    }
    /**
     * Start listening for events. Transitions to 'ready' state.
     * The recorder will automatically transition to 'recording' on the first mouse click.
     */
    start() {
      if (this.state !== "idle") return;
      this.events = [];
      this.pendingEvents = [];
      this.waitingForRelease = false;
      this.gameStartTime = 0;
      this.gameEndTime = 0;
      this.result = "unknown";
      this.lastEmittedX = -1;
      this.lastEmittedY = -1;
      this.frozen = false;
      this.frozenBuffer = [];
      this.setState("ready");
      this.mouseTracker.start(performance.now());
    }
    /**
     * Finish the current game and immediately reset to 'ready' for the next
     * game — **without ever stopping the mouse tracker**.
     *
     * This is the fast path for multi-game sessions. The mouse tracker's
     * event listeners stay attached to the board element continuously, so
     * there is zero gap where a fast player's click could be lost.
     *
     * Returns the completed game's RecordingData (same as getRecordingData()
     * would return after finish()), or null if the recorder wasn't recording.
     */
    finishAndReset(result, newMetadata) {
      if (this.state !== "recording" && this.state !== "ready") return null;
      this.result = result;
      let data = null;
      if (this.state === "recording") {
        this.trimTrailingMoves();
        const lastEvent = this.events[this.events.length - 1];
        const endTime = lastEvent ? lastEvent.timeMs : 0;
        data = {
          board: { ...this.board },
          minePositions: [...this.minePositions],
          events: [...this.events],
          metadata: { ...this.metadata },
          result: this.result,
          totalTimeMs: endTime
        };
      }
      this.events = [];
      this.pendingEvents = [];
      this.waitingForRelease = false;
      this.gameStartTime = 0;
      this.gameEndTime = 0;
      this.result = "unknown";
      this.minePositions = [];
      this.lastEmittedX = -1;
      this.lastEmittedY = -1;
      if (newMetadata) {
        this.metadata = newMetadata;
      }
      this.frozen = true;
      this.frozenBuffer = [];
      this.setState("ready");
      return data;
    }
    /**
     * Prevent the recorder from starting a new game while in 'ready' state.
     * Mouse events are buffered and replayed on unfreeze().
     */
    freeze() {
      this.frozen = true;
      this.frozenBuffer = [];
    }
    /**
     * Allow the recorder to start a new game.
     *
     * Replays buffered events from the freeze period through the normal
     * event handler. On minesweeper.online, the click that resets the board
     * also starts the new game — the mousedown fires before the face class
     * changes, so it lands in the freeze buffer. By replaying it here, the
     * first click of the new game is captured with zero loss.
     *
     * Only replays from the LAST press event onward — earlier events were
     * clicks on the end-game board that have no gameplay meaning.
     */
    unfreeze() {
      if (!this.frozen) return;
      this.frozen = false;
      let lastPressIndex = -1;
      for (let i = this.frozenBuffer.length - 1; i >= 0; i--) {
        if (isPressEvent(this.frozenBuffer[i].event)) {
          lastPressIndex = i;
          break;
        }
      }
      if (lastPressIndex >= 0) {
        const toReplay = this.frozenBuffer.slice(lastPressIndex);
        this.frozenBuffer = [];
        for (const event of toReplay) {
          this.onMouseEvent(event);
        }
      } else {
        this.frozenBuffer = [];
      }
    }
    /**
     * Stop recording without a result (manual stop / abort).
     */
    abort() {
      this.mouseTracker.stop();
      this.frozen = false;
      this.frozenBuffer = [];
      if (this.state === "recording") {
        this.gameEndTime = Math.round(performance.now() - this.gameStartTime);
      }
      this.result = "unknown";
      this.setState("finished");
    }
    /**
     * Get the complete recording data, ready for RAWVF generation.
     * Only valid in 'finished' state.
     */
    getRecordingData() {
      if (this.state !== "finished") return null;
      return {
        board: { ...this.board },
        minePositions: [...this.minePositions],
        events: [...this.events],
        metadata: { ...this.metadata },
        result: this.result,
        totalTimeMs: this.gameEndTime
      };
    }
    // --------------------------------------------------------------------------
    // Event handlers
    // --------------------------------------------------------------------------
    onMouseEvent(event) {
      if (this.state === "ready") {
        if (this.frozen) {
          this.frozenBuffer.push(event);
          return;
        }
        if (isPressEvent(event.event)) {
          this.pendingEvents.push(event);
          this.waitingForRelease = true;
          return;
        }
        if (this.waitingForRelease && isReleaseEvent(event.event)) {
          const gameStartTimestamp = event.rawTimestamp;
          this.gameStartTime = gameStartTimestamp;
          this.mouseTracker.setGameStartTime(gameStartTimestamp);
          for (const pending of this.pendingEvents) {
            this.events.push({ ...pending, timeMs: 0, x: event.x, y: event.y });
          }
          this.pendingEvents = [];
          this.waitingForRelease = false;
          this.events.push({ ...event, timeMs: 0 });
          this.lastEmittedX = event.x;
          this.lastEmittedY = event.y;
          this.setState("recording");
          return;
        }
        return;
      }
      if (this.state === "recording") {
        if (event.event === "mv" && this.lastEmittedX >= 0 && event.x === this.lastEmittedX && event.y === this.lastEmittedY) {
          this.lastEmittedX = -1;
          this.lastEmittedY = -1;
          return;
        }
        this.lastEmittedX = -1;
        this.lastEmittedY = -1;
        this.events.push(event);
      }
    }
    // --------------------------------------------------------------------------
    // Internal
    // --------------------------------------------------------------------------
    /**
     * Remove trailing 'mv' events that occur after the last release event.
     * These are artefacts of the slight delay between the actual game end
     * (final release) and the MutationObserver firing to signal finish().
     */
    trimTrailingMoves() {
      while (this.events.length > 0) {
        const last = this.events[this.events.length - 1];
        if (last.event === "mv") {
          this.events.pop();
        } else {
          break;
        }
      }
    }
    setState(newState) {
      this.state = newState;
      this.onStateChange?.(newState);
    }
  };
  function isPressEvent(code) {
    return code === "lc" || code === "rc" || code === "mc" || code === "sc";
  }
  function isReleaseEvent(code) {
    return code === "lr" || code === "rr" || code === "mr";
  }

  // src/lib/utils/format.ts
  function formatDateForFilename(timestamp2) {
    try {
      const date = timestamp2 ? new Date(timestamp2) : /* @__PURE__ */ new Date();
      return date.toISOString().replace(/[-:T]/g, "").replace(/\.\d+Z$/, "").replace(/(\d{8})(\d{6})/, "$1_$2");
    } catch {
      return "unknown";
    }
  }

  // src/lib/rawvf/writer.ts
  function generateRawvf(recording) {
    const description = buildDescription(recording);
    const board = buildBoard(recording);
    const events = buildEvents(recording);
    return `${description}
${board}
${events}
`;
  }
  function generateFilename(recording) {
    const level = resolveLevelName(
      recording.metadata.levelCode,
      recording.board.cols,
      recording.board.rows,
      recording.board.mines
    );
    const timeSec = (recording.totalTimeMs / 1e3).toFixed(3);
    const dateStr = formatDateForFilename(recording.metadata.timestamp);
    return `${dateStr}_${level}_${timeSec}s.rawvf`;
  }
  function buildDescription(recording) {
    const { board, metadata, result, totalTimeMs } = recording;
    const lines = [];
    lines.push("RawVF_Version: Rev7");
    lines.push(`Program: ${metadata.program}`);
    if (metadata.version) {
      lines.push(`Version: ${metadata.version}`);
    }
    if (metadata.player) {
      lines.push(`Player: ${metadata.player}`);
    }
    if (metadata.opponent) {
      lines.push(`Opponent: ${metadata.opponent}`);
    }
    if (metadata.url) {
      lines.push(`URL: ${metadata.url}`);
    }
    if (metadata.opponentUrl) {
      lines.push(`OpponentURL: ${metadata.opponentUrl}`);
    }
    if (metadata.timestamp) {
      lines.push(`Timestamp: ${metadata.timestamp}`);
    }
    const level = resolveLevelName(metadata.levelCode, board.cols, board.rows, board.mines);
    lines.push(`Level: ${level}`);
    lines.push(`Width: ${board.cols}`);
    lines.push(`Height: ${board.rows}`);
    lines.push(`Mines: ${board.mines}`);
    lines.push(`Marks: ${metadata.questionMarks ? "On" : "Off"}`);
    if (metadata.chordingMode === "superclick") {
      lines.push("SuperClick: On");
    } else if (metadata.chordingMode) {
      lines.push("SuperClick: Off");
    }
    if (board.squareSize !== 16) {
      lines.push(`SquareSize: ${board.squareSize}`);
    }
    if (recording.events.some((event) => event.type === "board")) {
      lines.push("BoardEvents: On");
    }
    lines.push("DestructiveOpenings: On");
    lines.push(`Time: ${formatRawvfTime(totalTimeMs)}`);
    if (result === "won") {
      lines.push("Status: won");
    } else if (result === "lost") {
      lines.push("Status: lost");
    }
    const mode = resolveGameMode(metadata.levelCode, metadata.isPvp);
    lines.push(`Mode: ${mode}`);
    return lines.join("\n");
  }
  function buildBoard(recording) {
    const { board, minePositions } = recording;
    const grid = [];
    for (let row = 0; row < board.rows; row++) {
      grid.push(new Array(board.cols).fill("0"));
    }
    for (const mine of minePositions) {
      if (mine.row < 0 || mine.row >= board.rows || mine.col < 0 || mine.col >= board.cols) {
        console.error(
          `[MSR] Mine position out of bounds: (row=${mine.row}, col=${mine.col}) on ${board.cols}x${board.rows} board.`
        );
        continue;
      }
      grid[mine.row][mine.col] = "*";
    }
    const lines = ["Board:"];
    for (const row of grid) {
      lines.push(row.join(""));
    }
    return lines.join("\n");
  }
  function buildEvents(recording) {
    const lines = ["Events:"];
    const squareSize = recording.board.squareSize;
    for (const event of recording.events) {
      lines.push(event.type === "mouse" ? formatMouseEvent(event, squareSize) : formatBoardEvent(event));
    }
    return lines.join("\n");
  }
  function formatMouseEvent(event, squareSize) {
    const time = formatRawvfTime(event.timeMs);
    const cellCol = pixelToCell1Indexed(event.x, squareSize);
    const cellRow = pixelToCell1Indexed(event.y, squareSize);
    return `${time} ${event.event} ${cellCol} ${cellRow} (${event.x} ${event.y})`;
  }
  function formatBoardEvent(event) {
    return `${event.event} ${event.col + 1} ${event.row + 1}`;
  }
  function formatRawvfTime(timeMs) {
    const negative = timeMs < 0;
    const absMs = Math.abs(timeMs);
    const seconds = Math.floor(absMs / 1e3);
    const millis = absMs % 1e3;
    const prefix = negative ? "-" : "";
    return `${prefix}${seconds}.${millis.toString().padStart(3, "0")}`;
  }
  function pixelToCell1Indexed(pixel, squareSize) {
    if (pixel < 0) return 0;
    return Math.floor(pixel / squareSize) + 1;
  }
  function resolveLevelName(levelCode, cols, rows, mines) {
    if (levelCode != null) {
      const name = LEVEL_CODE_TO_NAME[levelCode];
      if (name) return name;
    }
    if (cols === 8 && rows === 8 && mines === 10) return "Beginner";
    if (cols === 16 && rows === 16 && mines === 40) return "Intermediate";
    if (cols === 30 && rows === 16 && mines === 99) return "Expert";
    return "Custom";
  }
  function resolveGameMode(levelCode, isPvp) {
    if (isPvp) return "PVP";
    if (levelCode != null && levelCode >= 11 && levelCode <= 15) return "No Guess";
    return "Classic";
  }
  var LEVEL_CODE_TO_NAME = {
    1: "Beginner",
    2: "Intermediate",
    3: "Expert",
    4: "Custom",
    11: "Easy",
    12: "Medium",
    13: "Hard",
    14: "Evil",
    15: "Custom"
  };

  // src/lib/rawvf/womConverter.ts
  var DEFAULT_SQUARE_SIZE = 16;
  var WOM_STATE_WON = 3;
  var WOM_STATE_LOST = 2;
  var MOVE_LEAD_TIME_MS = 500;
  var MOVE_STEP_INTERVAL_MS = 15;
  function convertWomReplay(data) {
    if (!Array.isArray(data) || data.length < 3) {
      throw new Error("Invalid WoM replay data: expected array with at least 3 elements");
    }
    const gameMeta = validateGameMeta(data[0]);
    const boardData = validateBoardData(data[1], gameMeta.sizeX, gameMeta.sizeY);
    const clicks = validateClicks(data[2]);
    const cols = gameMeta.sizeX;
    const rows = gameMeta.sizeY;
    const minePositions = extractMinePositions(boardData.t, rows);
    const chordingMode = resolveChordingMode(gameMeta.clickType);
    const isPvp = gameMeta.duelInfo != null;
    const opponentInfo = resolveOpponentInfo(gameMeta);
    const clickGroups = buildClickGroups(clicks, DEFAULT_SQUARE_SIZE, chordingMode, isPvp);
    const events = buildEventStream(clickGroups);
    const result = resolveGameResult(gameMeta.state);
    const totalTimeMs = gameMeta.duration;
    const recording = {
      board: {
        cols,
        rows,
        mines: gameMeta.mines,
        squareSize: DEFAULT_SQUARE_SIZE
      },
      minePositions,
      events,
      metadata: {
        program: "Minesweeper Online",
        timestamp: gameMeta.finishedAt ?? gameMeta.createdAt ?? (/* @__PURE__ */ new Date()).toISOString(),
        player: gameMeta.userId != null ? String(gameMeta.userId) : void 0,
        questionMarks: false,
        chordingMode,
        url: `https://minesweeper.online/game/${gameMeta.id}`,
        opponent: opponentInfo ? String(opponentInfo.opponentUserId) : void 0,
        opponentUrl: opponentInfo?.opponentGameId != null ? `https://minesweeper.online/game/${opponentInfo.opponentGameId}` : void 0,
        levelCode: gameMeta.level,
        isPvp
      },
      result,
      totalTimeMs
    };
    return { recording, gameId: gameMeta.id };
  }
  function validateGameMeta(raw) {
    if (!raw || typeof raw !== "object") {
      throw new Error("Invalid WoM game metadata: expected an object");
    }
    const meta = raw;
    const id = meta.id;
    const sizeX = meta.sizeX;
    const sizeY = meta.sizeY;
    const mines = meta.mines;
    const state = meta.state;
    const duration = meta.duration;
    if (typeof id !== "number" || typeof sizeX !== "number" || typeof sizeY !== "number" || typeof mines !== "number" || typeof state !== "number" || typeof duration !== "number") {
      throw new Error("Invalid WoM game metadata: missing required numeric fields (id, sizeX, sizeY, mines, state, duration)");
    }
    if (sizeX < 1 || sizeX > 100 || sizeY < 1 || sizeY > 100) {
      throw new Error(`Invalid board dimensions: ${sizeX}x${sizeY}`);
    }
    if (mines < 0 || mines > sizeX * sizeY) {
      throw new Error(`Invalid mine count: ${mines} for ${sizeX}x${sizeY} board`);
    }
    return {
      id,
      sizeX,
      sizeY,
      mines,
      state,
      duration,
      nf: typeof meta.nf === "number" ? meta.nf : 0,
      clickType: typeof meta.clickType === "number" ? meta.clickType : 0,
      bbbv: typeof meta.bbbv === "number" ? meta.bbbv : void 0,
      bbbvs: typeof meta.bbbvs === "number" ? meta.bbbvs : void 0,
      eff100: typeof meta.eff100 === "number" ? meta.eff100 : void 0,
      clicks: typeof meta.clicks === "number" ? meta.clicks : void 0,
      mobile: typeof meta.mobile === "number" ? meta.mobile : void 0,
      createdAt: typeof meta.createdAt === "string" ? meta.createdAt : void 0,
      finishedAt: typeof meta.finishedAt === "string" ? meta.finishedAt : void 0,
      userId: typeof meta.userId === "number" ? meta.userId : void 0,
      level: typeof meta.level === "number" ? meta.level : void 0,
      duelInfo: parseDuelInfo(meta.duelInfo)
    };
  }
  function parseDuelInfo(raw) {
    if (!raw || typeof raw !== "object") return void 0;
    const d = raw;
    if (typeof d.id !== "number" || typeof d.user1Id !== "number" || typeof d.user2Id !== "number") {
      return void 0;
    }
    return {
      id: d.id,
      user1Id: d.user1Id,
      user2Id: d.user2Id,
      game1Id: typeof d.game1Id === "number" ? d.game1Id : null,
      game2Id: typeof d.game2Id === "number" ? d.game2Id : null
    };
  }
  function validateBoardData(raw, cols, rows) {
    if (!raw || typeof raw !== "object") {
      throw new Error("Invalid WoM board data: expected an object");
    }
    const board = raw;
    const expectedLen = cols * rows;
    const t = board.t;
    if (!Array.isArray(t) || t.length !== expectedLen) {
      throw new Error(`Invalid tile array: expected length ${expectedLen}, got ${Array.isArray(t) ? t.length : "non-array"}`);
    }
    const o = Array.isArray(board.o) ? board.o : [];
    const f = Array.isArray(board.f) ? board.f : [];
    return { t, o, f };
  }
  function validateClicks(raw) {
    if (!Array.isArray(raw)) {
      throw new Error("Invalid WoM clicks: expected an array");
    }
    return raw.map((click, i) => {
      if (!click || typeof click !== "object") {
        throw new Error(`Invalid click at index ${i}: expected an object`);
      }
      const c = click;
      if (typeof c.type !== "number" || typeof c.time !== "number" || typeof c.x !== "number" || typeof c.y !== "number") {
        throw new Error(`Invalid click at index ${i}: missing required fields (type, time, x, y)`);
      }
      let touchCells;
      if (c.touchCells !== void 0) {
        if (!Array.isArray(c.touchCells) || c.touchCells.length % 5 !== 0) {
          throw new Error(`Invalid click at index ${i}: touchCells must be an array with length divisible by 5`);
        }
        touchCells = c.touchCells;
      }
      return {
        type: c.type,
        time: c.time,
        x: c.x,
        y: c.y,
        touchCells
      };
    });
  }
  function tileIndexToPosition(index, numRows) {
    return {
      row: index % numRows,
      col: Math.floor(index / numRows)
    };
  }
  function womXYToPixel(x, y, squareSize) {
    return {
      px: x * squareSize + Math.floor(squareSize / 2),
      py: y * squareSize + Math.floor(squareSize / 2)
    };
  }
  function extractMinePositions(tiles, numRows) {
    const mines = [];
    for (let i = 0; i < tiles.length; i++) {
      if (tiles[i] === 10 || tiles[i] === 11) {
        mines.push(tileIndexToPosition(i, numRows));
      }
    }
    return mines;
  }
  function resolveGameResult(state) {
    if (state === WOM_STATE_WON) return "won";
    if (state === WOM_STATE_LOST) return "lost";
    return "unknown";
  }
  function resolveChordingMode(clickType) {
    if (clickType === 1) return "superclick";
    if (clickType === 2) return "both";
    if (clickType === 3) return "disabled";
    return "disabled";
  }
  function resolveOpponentInfo(gameMeta) {
    const duelInfo = gameMeta.duelInfo;
    if (!duelInfo) return void 0;
    if (duelInfo.game1Id === gameMeta.id) {
      return { opponentUserId: duelInfo.user2Id, opponentGameId: duelInfo.game2Id };
    }
    if (duelInfo.game2Id === gameMeta.id) {
      return { opponentUserId: duelInfo.user1Id, opponentGameId: duelInfo.game1Id };
    }
    return void 0;
  }
  function mouseEventsForClick(click, squareSize, chordingMode) {
    const { px, py } = womXYToPixel(click.x, click.y, squareSize);
    if (click.type === 1) {
      return [makeEvent(click.time, "rc", px, py), makeEvent(click.time, "rr", px, py)];
    } else if (click.type === 2) {
      return [makeEvent(click.time, "mc", px, py), makeEvent(click.time, "mr", px, py)];
    } else if (click.type === 3) {
      if (chordingMode === "superclick") {
        return [makeEvent(click.time, "lc", px, py), makeEvent(click.time, "lr", px, py)];
      }
      return [makeEvent(click.time, "mc", px, py), makeEvent(click.time, "mr", px, py)];
    } else {
      return [makeEvent(click.time, "lc", px, py), makeEvent(click.time, "lr", px, py)];
    }
  }
  function makeEvent(timeMs, event, x, y) {
    return { type: "mouse", timeMs, event, x, y, rawTimestamp: 0 };
  }
  function chunksToBoardEvents(touchCells, clickType) {
    if (!touchCells || touchCells.length === 0) return [];
    if (touchCells.length % 5 !== 0) {
      console.error(`[MSR] Malformed touchCells array: length ${touchCells.length} is not a multiple of 5.`);
      return [];
    }
    const originEvents = [];
    const otherEvents = [];
    for (let i = 0; i < touchCells.length; i += 5) {
      const col = touchCells[i];
      const row = touchCells[i + 1];
      const code = touchCells[i + 2];
      const index3 = touchCells[i + 3];
      const index4 = touchCells[i + 4];
      if (clickType === 1) {
        otherEvents.push({ type: "board", col, row, event: index4 === 1 ? "flag" : "closed" });
        continue;
      }
      const target = code === 13 ? originEvents : otherEvents;
      target.push(...chunkCodeToEvents(col, row, code, index3));
    }
    return [...originEvents, ...otherEvents];
  }
  function chunkCodeToEvents(col, row, code, index3) {
    if (code >= 0 && code <= 8) {
      return [{ type: "board", col, row, event: numberEventCode(code) }];
    }
    if (code === 10) {
      return [];
    }
    if (code === 11) {
      return [{ type: "board", col, row, event: "blast" }];
    }
    if (code === 12) {
      return [];
    }
    if (code === 13) {
      return getBlastOriginEvents().map((event) => ({ type: "board", col, row, event }));
    }
    if (code === 14) {
      return [
        { type: "board", col, row, event: "reset" },
        { type: "board", col, row, event: numberEventCode(index3) }
      ];
    }
    if (code === 15) {
      return [{ type: "board", col, row, event: "reset" }];
    }
    console.error(`[MSR] Unknown touchCells change code: ${code} at (${col}, ${row}).`);
    return [];
  }
  function getBlastOriginEvents() {
    return ["local_blast", "reset"];
  }
  function numberEventCode(n) {
    if (n < 0 || n > 8) {
      console.error(`[MSR] Unexpected revealed number value: ${n}, defaulting to number0.`);
      return "number0";
    }
    return `number${n}`;
  }
  function buildClickGroups(clicks, squareSize, chordingMode, isPvp) {
    return clicks.map((click) => ({
      timeMs: click.time,
      mouseEvents: mouseEventsForClick(click, squareSize, chordingMode),
      boardEvents: isPvp ? chunksToBoardEvents(click.touchCells, click.type) : []
    }));
  }
  function buildEventStream(groups) {
    if (groups.length === 0) return [];
    const result = [];
    result.push(...groups[0].mouseEvents, ...groups[0].boardEvents);
    for (let i = 1; i < groups.length; i++) {
      const prevGroup = groups[i - 1];
      const currGroup = groups[i];
      const fromX = prevGroup.mouseEvents[0].x;
      const fromY = prevGroup.mouseEvents[0].y;
      const toX = currGroup.mouseEvents[0].x;
      const toY = currGroup.mouseEvents[0].y;
      const prevTime = prevGroup.timeMs;
      const clickTime = currGroup.timeMs;
      const gap = clickTime - prevTime;
      const moveDuration = Math.min(MOVE_LEAD_TIME_MS, gap);
      const moveStart = clickTime - moveDuration;
      if ((fromX !== toX || fromY !== toY) && moveDuration >= MOVE_STEP_INTERVAL_MS) {
        const numSteps = Math.floor(moveDuration / MOVE_STEP_INTERVAL_MS);
        for (let step = 1; step <= numSteps; step++) {
          const t = step / numSteps;
          const mx = Math.round(fromX + (toX - fromX) * t);
          const my = Math.round(fromY + (toY - fromY) * t);
          const mt = Math.round(moveStart + moveDuration * (step / numSteps));
          if (mt < clickTime) {
            result.push(makeEvent(mt, "mv", mx, my));
          }
        }
      }
      result.push(...currGroup.mouseEvents, ...currGroup.boardEvents);
    }
    return result;
  }

  // src/lib/utils/socketIoParser.ts
  var SOCKETIO_EVENT_PREFIX = "42";
  var TARGET_EVENT_NAME = "response";
  var REPLAY_RESPONSE_CODE = 203;
  function parseSocketIoReplayFrame(payload) {
    if (!payload.startsWith(SOCKETIO_EVENT_PREFIX)) return null;
    const jsonStr = payload.slice(SOCKETIO_EVENT_PREFIX.length);
    let parsed;
    try {
      parsed = JSON.parse(jsonStr);
    } catch {
      return null;
    }
    if (!Array.isArray(parsed)) return null;
    if (parsed[0] !== TARGET_EVENT_NAME) return null;
    const responseArgs = parsed[1];
    if (!Array.isArray(responseArgs)) return null;
    if (responseArgs[1] !== REPLAY_RESPONSE_CODE) return null;
    const replayData = responseArgs[2];
    if (replayData == null) return null;
    return replayData;
  }
  function parseWomReplayPaste(rawText) {
    const trimmed = rawText.trim();
    const fromFrame = parseSocketIoReplayFrame(trimmed);
    if (fromFrame !== null) return fromFrame;
    let parsed;
    try {
      parsed = JSON.parse(trimmed);
    } catch {
      return null;
    }
    if (!Array.isArray(parsed)) return null;
    if (parsed[0] === TARGET_EVENT_NAME) {
      const responseArgs = parsed[1];
      if (Array.isArray(responseArgs) && responseArgs[1] === REPLAY_RESPONSE_CODE) {
        const replayData = responseArgs[2];
        if (replayData != null) return replayData;
      }
    }
    if (parsed.length >= 3 && parsed[0] && typeof parsed[0] === "object" && !Array.isArray(parsed[0])) {
      return parsed;
    }
    return null;
  }

  // src/lib/utils/log.ts
  var LEVEL_RANK = {
    debug: 0,
    info: 1,
    warn: 2,
    error: 3,
    silent: 4
  };
  var currentLevel = "debug";
  var currentPrefix = "[MSR";
  function shouldLog(level) {
    return LEVEL_RANK[level] >= LEVEL_RANK[currentLevel];
  }
  function timestamp() {
    return (/* @__PURE__ */ new Date()).toISOString();
  }
  var mlog = (...args) => {
    if (shouldLog("debug")) console.debug(`${currentPrefix} ${timestamp()}]`, ...args);
  };
  var minfo = (...args) => {
    if (shouldLog("info")) console.info(`${currentPrefix} ${timestamp()}]`, ...args);
  };
  var mwarn = (...args) => {
    if (shouldLog("warn")) console.warn(`${currentPrefix} ${timestamp()}]`, ...args);
  };
  var merr = (...args) => {
    if (shouldLog("error")) console.error(`${currentPrefix} ${timestamp()}]`, ...args);
  };

  // src/storage/gameStorage.ts
  var META_KEY = "replayMeta";
  var CONTENT_KEY_PREFIX = "replay_";
  var STORAGE_BUDGET_BYTES = 50 * 1024 * 1024;
  async function saveGame(meta, rawvf) {
    const id = generateId();
    const sizeBytes = new TextEncoder().encode(rawvf).byteLength;
    const allMeta = await loadMeta();
    const newMeta = { ...meta, id, sizeBytes };
    allMeta.push(newMeta);
    let totalSize = allMeta.reduce((sum, g) => sum + g.sizeBytes, 0);
    const evictIds = [];
    while (totalSize > STORAGE_BUDGET_BYTES && allMeta.length > 1) {
      const oldest = allMeta.shift();
      totalSize -= oldest.sizeBytes;
      evictIds.push(oldest.id);
    }
    await browser_default.storage.local.set({
      [META_KEY]: allMeta,
      [`${CONTENT_KEY_PREFIX}${id}`]: rawvf
    });
    if (evictIds.length > 0) {
      await browser_default.storage.local.remove(
        evictIds.map((eid) => `${CONTENT_KEY_PREFIX}${eid}`)
      );
      minfo(`Evicted ${evictIds.length} old replay(s) to stay within storage budget`);
    }
    minfo(`Replay saved: ${meta.filename} (${(sizeBytes / 1024).toFixed(1)} KB, ${allMeta.length} total)`);
  }
  async function loadMeta() {
    const data = await browser_default.storage.local.get(META_KEY);
    return data[META_KEY] ?? [];
  }
  function generateId() {
    return `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  }

  // src/lib/types/settings.ts
  var DEFAULT_SETTINGS = {
    chording: "both",
    keyboardMouse: {
      enabled: false,
      leftKeyCode: 32,
      // Space
      rightKeyCode: 32
      // Space
    }
  };

  // src/storage/settingsStorage.ts
  var SETTINGS_KEY = "gameSettings";
  async function loadSettings() {
    const data = await browser_default.storage.local.get(SETTINGS_KEY);
    const stored = data[SETTINGS_KEY];
    if (stored) {
      return stored;
    }
    return {
      autoDetectedSettings: null,
      manualSettings: null,
      manualOverride: false,
      lastUpdated: ""
    };
  }
  async function saveAutoDetectedSettings(settings) {
    const current = await loadSettings();
    const stored = {
      ...current,
      autoDetectedSettings: settings,
      lastUpdated: (/* @__PURE__ */ new Date()).toISOString()
    };
    await browser_default.storage.local.set({ [SETTINGS_KEY]: stored });
    minfo("Auto-detected settings saved:", settings.chording, "| keyboard:", settings.keyboardMouse.enabled);
  }
  async function getEffectiveSettings() {
    const stored = await loadSettings();
    if (stored.manualOverride && stored.manualSettings) {
      return stored.manualSettings;
    }
    return stored.autoDetectedSettings ?? { ...DEFAULT_SETTINGS };
  }

  // src/lib/site/minesweeperOnline.ts
  var VALID_CELL_SUFFIXES = /* @__PURE__ */ new Set([
    "closed",
    "flag",
    "pressed",
    "type0",
    "type1",
    "type2",
    "type3",
    "type4",
    "type5",
    "type6",
    "type7",
    "type8",
    "type10",
    "type11",
    "type12"
  ]);
  function getSkinPrefix() {
    const game = document.getElementById("game");
    if (!game) return null;
    for (const cls of game.classList) {
      if (cls.startsWith("skin_")) {
        return cls.slice(5);
      }
    }
    return null;
  }
  function extractStateSuffixes(cellElement, skinPrefix) {
    const prefix = skinPrefix + "_";
    const suffixes = [];
    for (const cls of cellElement.classList) {
      if (cls.startsWith(prefix)) {
        const suffix = cls.slice(prefix.length);
        if (VALID_CELL_SUFFIXES.has(suffix)) {
          suffixes.push(suffix);
        }
      }
    }
    return suffixes;
  }
  function getCellSize() {
    const cell = document.querySelector(".cell");
    if (!cell) return 24;
    for (const cls of cell.classList) {
      const match = cls.match(/^size(\d+)$/);
      if (match) {
        return parseInt(match[1], 10);
      }
    }
    return 24;
  }
  function detectFaceState() {
    const face = document.getElementById("top_area_face");
    if (!face) return null;
    for (const cls of face.classList) {
      if (cls.includes("face-win") || cls.includes("face_win")) return "won";
      if (cls.includes("face-lose") || cls.includes("face_lose")) return "lost";
    }
    return null;
  }
  function extractCellPosition(cellElement) {
    const xAttr = cellElement.getAttribute("data-x");
    const yAttr = cellElement.getAttribute("data-y");
    if (xAttr === null || yAttr === null) return null;
    return {
      col: parseInt(xAttr, 10),
      row: parseInt(yAttr, 10)
    };
  }
  function parseChordingValue(value) {
    switch (value) {
      case "1":
        return "superclick";
      case "2":
        return "both";
      case "3":
        return "disabled";
      default:
        return DEFAULT_SETTINGS.chording;
    }
  }
  function readSettingsFromDOM() {
    const chordingEl = document.getElementById("property_chording");
    if (!chordingEl) return null;
    const chording = parseChordingValue(chordingEl.value);
    const keyboardEl = document.getElementById("property_use_keyboard");
    const leftKeyEl = document.getElementById("property_use_keyboard_left_button");
    const rightKeyEl = document.getElementById("property_use_keyboard_right_button");
    const keyboardEnabled = keyboardEl?.checked ?? false;
    const leftKeyCode = leftKeyEl ? parseInt(leftKeyEl.value, 10) : DEFAULT_SETTINGS.keyboardMouse.leftKeyCode;
    const rightKeyCode = rightKeyEl ? parseInt(rightKeyEl.value, 10) : DEFAULT_SETTINGS.keyboardMouse.rightKeyCode;
    return {
      chording,
      keyboardMouse: {
        enabled: keyboardEnabled,
        leftKeyCode: isNaN(leftKeyCode) ? DEFAULT_SETTINGS.keyboardMouse.leftKeyCode : leftKeyCode,
        rightKeyCode: isNaN(rightKeyCode) ? DEFAULT_SETTINGS.keyboardMouse.rightKeyCode : rightKeyCode
      }
    };
  }
  function parseLocalStorageSettings(data) {
    const chordingRaw = data["_chording"];
    const useKeyboardRaw = data["_use_keyboard"];
    const leftKeyRaw = data["_use_keyboard_left_button"];
    const rightKeyRaw = data["_use_keyboard_right_button"];
    const chording = chordingRaw ? parseChordingValue(chordingRaw) : DEFAULT_SETTINGS.chording;
    const keyboardEnabled = useKeyboardRaw === "1";
    const leftKeyCode = leftKeyRaw ? parseInt(leftKeyRaw, 10) : DEFAULT_SETTINGS.keyboardMouse.leftKeyCode;
    const rightKeyCode = rightKeyRaw ? parseInt(rightKeyRaw, 10) : DEFAULT_SETTINGS.keyboardMouse.rightKeyCode;
    return {
      chording,
      keyboardMouse: {
        enabled: keyboardEnabled,
        leftKeyCode: isNaN(leftKeyCode) ? DEFAULT_SETTINGS.keyboardMouse.leftKeyCode : leftKeyCode,
        rightKeyCode: isNaN(rightKeyCode) ? DEFAULT_SETTINGS.keyboardMouse.rightKeyCode : rightKeyCode
      }
    };
  }
  var SETTINGS_LOCALSTORAGE_KEYS = [
    "_chording",
    "_use_keyboard",
    "_use_keyboard_left_button",
    "_use_keyboard_right_button"
  ];
  function readSettingsFromLocalStorage() {
    const data = {};
    for (const key of SETTINGS_LOCALSTORAGE_KEYS) {
      data[key] = localStorage.getItem(key);
    }
    return data;
  }
  var SETTINGS_POLL_INTERVAL_MS = 2e3;
  var MinesweeperOnlineSite = class {
    faceObserver = null;
    resetObserver = null;
    boardChangeObserver = null;
    // Settings polling state
    settingsPollInterval = null;
    cachedLocalStorageSettings = null;
    getProgramName() {
      return "Minesweeper Online";
    }
    /** No reliable version string is available from the DOM. */
    getVersion() {
      return "";
    }
    /** The currently logged-in player's display name, or null if logged out. */
    getPlayerName() {
      const el = document.querySelector(".header_username");
      return el?.textContent?.trim() || null;
    }
    /** True when the page is on the minesweeper.online host. */
    matches() {
      return window.location.hostname === "minesweeper.online";
    }
    /** True when the URL is a game page (i.e., could host a board). */
    isGamePage() {
      return window.location.pathname.startsWith("/game/");
    }
    /** Permalink of the current game, or null if not on a game page. */
    getGameURL() {
      if (window.location.pathname.startsWith("/game/")) {
        return window.location.href;
      }
      return null;
    }
    /**
     * The active level code from the level selector.
     * Classic: 1=Beginner, 2=Intermediate, 3=Expert, 4=Custom
     * No Guess: 11=Easy, 12=Medium, 13=Hard, 14=Evil, 15=Custom
     */
    getGameLevel() {
      const activeLink = document.querySelector("#levels_full .level-select-link.active");
      if (!activeLink) return null;
      const id = activeLink.id;
      const match = id.match(/^level_select_(\d+)$/);
      if (!match) return null;
      return parseInt(match[1], 10);
    }
    /** The board container element, or null if not present. */
    findBoardElement() {
      return document.getElementById("AreaBlock");
    }
    /**
     * The wrapper element surrounding the board. Clicks on its border that
     * drag into the board are treated as valid clicks by the site.
     */
    findBorderElement() {
      return document.getElementById("game");
    }
    /**
     * Board dimensions and cell size. Mine count is left at 0 — it is derived
     * from mine positions after the game ends, keeping pre-game DOM reads minimal.
     */
    getBoardConfig() {
      const cells = document.getElementById("AreaBlock")?.querySelectorAll(".cell");
      if (!cells || cells.length === 0) return null;
      const lastCell = cells[cells.length - 1];
      const cols = parseInt(lastCell.getAttribute("data-x") ?? "0", 10) + 1;
      const rows = parseInt(lastCell.getAttribute("data-y") ?? "0", 10) + 1;
      const squareSize = getCellSize();
      return { cols, rows, mines: 0, squareSize };
    }
    /**
     * Mine positions from the post-game DOM. Returns [] during gameplay because
     * cell classes don't reliably indicate mine locations until the game ends.
     *
     * @param result — On a win, cells still in 'closed' state are mines (all
     *   non-mines have been opened), so we include them even if the site's
     *   auto-flag animation hasn't run yet.
     */
    getMinePositions(result) {
      const faceState = detectFaceState();
      mlog("getMinePositions called: result =", result, ", faceState =", faceState);
      if (!result || faceState === null) {
        mlog("getMinePositions: guard failed, returning []");
        return [];
      }
      const prefix = getSkinPrefix() ?? "hdd";
      const mines = [];
      const cells = document.getElementById("AreaBlock")?.querySelectorAll(".cell") ?? [];
      for (const cell of cells) {
        const suffixes = extractStateSuffixes(cell, prefix);
        const isMine = suffixes.includes("type10") || suffixes.includes("type11") || suffixes.includes("flag") || result === "won" && suffixes.includes("closed");
        if (isMine) {
          const pos = extractCellPosition(cell);
          if (pos) {
            mines.push(pos);
          }
        }
      }
      return mines;
    }
    /**
     * Register a one-shot callback for game end (win or loss).
     * The callback fires once when the face transitions to win/lose; the
     * observer is then cleaned up. Re-register after each game.
     */
    onGameEnd(callback) {
      const face = document.getElementById("top_area_face");
      if (!face) {
        mwarn("onGameEnd: #top_area_face not found in DOM");
        return;
      }
      mlog("onGameEnd: setting up face observer on", face.className);
      if (this.faceObserver) {
        this.faceObserver.disconnect();
      }
      let seenNeutral = !detectFaceState();
      this.faceObserver = new MutationObserver(() => {
        mlog("Face class changed:", face.className);
        const result = detectFaceState();
        if (!result) {
          seenNeutral = true;
          return;
        }
        if (!seenNeutral) {
          mlog("onGameEnd: ignoring face change (seenNeutral=false, same end-state)");
          return;
        }
        mlog("detectFaceState() =", result);
        this.faceObserver?.disconnect();
        this.faceObserver = null;
        callback(result);
      });
      this.faceObserver.observe(face, {
        attributes: true,
        attributeFilter: ["class"]
      });
    }
    /** Cancel a pending onGameEnd watcher. */
    cancelGameEnd() {
      if (this.faceObserver) {
        this.faceObserver.disconnect();
        this.faceObserver = null;
      }
    }
    /**
     * One-shot callback for board reset (player starts a new game after a
     * previous one ended). Detects the face returning to neutral.
     */
    onBoardReset(callback) {
      const face = document.getElementById("top_area_face");
      if (!face) {
        mwarn("onBoardReset: #top_area_face not found");
        return;
      }
      mlog("onBoardReset: watching for face to return to neutral");
      if (this.resetObserver) {
        this.resetObserver.disconnect();
      }
      this.resetObserver = new MutationObserver(() => {
        const state = detectFaceState();
        mlog("onBoardReset: face changed, detectFaceState() =", state);
        if (!state) {
          mlog("Board reset detected");
          this.resetObserver?.disconnect();
          this.resetObserver = null;
          callback();
        }
      });
      this.resetObserver.observe(face, {
        attributes: true,
        attributeFilter: ["class"]
      });
    }
    cancelBoardReset() {
      if (this.resetObserver) {
        this.resetObserver.disconnect();
        this.resetObserver = null;
      }
    }
    /**
     * Persistent callback for board layout changes (e.g. user switched
     * difficulty). Fires on childList mutations of #AreaBlock — same-size
     * restarts only change cell classes and won't trigger this.
     */
    onBoardChange(callback) {
      const board = document.getElementById("AreaBlock");
      if (!board) return;
      if (this.boardChangeObserver) {
        this.boardChangeObserver.disconnect();
      }
      this.boardChangeObserver = new MutationObserver(() => {
        requestAnimationFrame(() => callback());
      });
      this.boardChangeObserver.observe(board, { childList: true });
    }
    cancelBoardChange() {
      if (this.boardChangeObserver) {
        this.boardChangeObserver.disconnect();
        this.boardChangeObserver = null;
      }
    }
    // ----------------------------------------------------------------------
    // Settings detection
    // ----------------------------------------------------------------------
    isSettingsPage() {
      return window.location.pathname === "/settings";
    }
    /**
     * Read the current effective settings. Prefers the cached localStorage
     * values (available on any page); falls back to DOM parsing if on the
     * settings page.
     */
    readSettings() {
      if (this.cachedLocalStorageSettings) return this.cachedLocalStorageSettings;
      return readSettingsFromDOM();
    }
    /**
     * Start polling the site's localStorage for game settings. Calls back
     * immediately with current values, then again on every detected change.
     * Idempotent — calling twice without destroying does nothing.
     */
    initSettingsBridge(callback) {
      if (this.settingsPollInterval) return;
      const pollSettings = () => {
        const data = readSettingsFromLocalStorage();
        const settings = parseLocalStorageSettings(data);
        const changed = JSON.stringify(settings) !== JSON.stringify(this.cachedLocalStorageSettings);
        this.cachedLocalStorageSettings = settings;
        if (changed) {
          mlog("Settings from localStorage:", settings);
          callback(settings);
        }
      };
      pollSettings();
      this.settingsPollInterval = setInterval(pollSettings, SETTINGS_POLL_INTERVAL_MS);
      mlog("localStorage settings polling started");
    }
    destroySettingsBridge() {
      if (this.settingsPollInterval) {
        clearInterval(this.settingsPollInterval);
        this.settingsPollInterval = null;
      }
      this.cachedLocalStorageSettings = null;
    }
  };

  // src/content/index.ts
  var GUARD_KEY = "__minesweeper_replay_generator_loaded__";
  if (window[GUARD_KEY]) {
    throw new Error("[MSR] Content script already loaded, skipping duplicate.");
  }
  window[GUARD_KEY] = true;
  var BOARD_POLL_INTERVAL_MS = 200;
  var URL_POLL_INTERVAL_MS = 40;
  var sessionActive = false;
  var currentAdapter = null;
  var sessionGameCount = 0;
  var recorder = null;
  var currentState = "idle";
  var playerName;
  var boardPresenceInterval = null;
  var lastKnownBoardElement = null;
  var currentSettings = null;
  var navigationMonitorInterval = null;
  var settingsBridgeAdapter = null;
  function cancelAllWatchers(adapter) {
    adapter?.cancelBoardReset?.();
    adapter?.cancelBoardChange?.();
    adapter?.cancelGameEnd?.();
  }
  function abortAndSaveRecorder() {
    if (!recorder) return false;
    const state = recorder.getState();
    if (state === "recording") {
      recorder.abort();
      const data = recorder.getRecordingData();
      if (data) saveRecordingData(data);
    } else {
      recorder.abort();
    }
    recorder = null;
    return true;
  }
  function isContextValid() {
    try {
      return browser_default.runtime?.id != null;
    } catch {
      return false;
    }
  }
  function teardownOnInvalidContext() {
    mlog("Extension context invalidated, tearing down content script");
    sessionActive = false;
    stopBoardPresenceMonitor();
    if (navigationMonitorInterval !== null) {
      clearInterval(navigationMonitorInterval);
      navigationMonitorInterval = null;
    }
    cancelAllWatchers(currentAdapter);
    settingsBridgeAdapter?.destroySettingsBridge?.();
    settingsBridgeAdapter = null;
    if (recorder) {
      recorder.abort();
      recorder = null;
    }
    currentState = "idle";
    delete window[GUARD_KEY];
  }
  browser_default.runtime.onMessage.addListener((message, _sender) => {
    const msg = message;
    switch (msg.type) {
      case "START_RECORDING":
        playerName = msg.playerName;
        return handleStartSession().catch((err) => ({ error: String(err) }));
      case "STOP_RECORDING":
        handleStopSession();
        return Promise.resolve({ success: true });
      case "GET_STATUS":
        return Promise.resolve(getStatus());
      case "GET_SETTINGS":
        return getEffectiveSettings().then((s) => ({ settings: s }));
      case "WS_REPLAY_DATA":
        return Promise.resolve(handleWomReplayData(msg.data));
      case "PARSE_WS_REPLAY": {
        const rawText = msg.rawText;
        if (!rawText) {
          return Promise.resolve({ success: false, error: "No text provided" });
        }
        const parsed = parseWomReplayPaste(rawText);
        if (parsed === null) {
          return Promise.resolve({ success: false, error: 'Could not parse input. Expected a socket.io frame (42["response",[...]]) or a raw JSON replay array.' });
        }
        return Promise.resolve(handleWomReplayData(parsed));
      }
    }
  });
  async function handleStartSession() {
    if (sessionActive) {
      mlog("handleStartSession: session already active, skipping");
      return { success: true };
    }
    const adapter = new MinesweeperOnlineSite();
    if (!adapter.matches()) {
      return {
        success: false,
        error: "Could not detect a minesweeper board on this page. Make sure you are on a supported minesweeper website."
      };
    }
    const boardElement = adapter.findBoardElement();
    if (!boardElement) {
      return {
        success: false,
        error: "Minesweeper board element not found on this page."
      };
    }
    const boardConfig = adapter.getBoardConfig();
    if (!boardConfig) {
      return {
        success: false,
        error: "Could not determine board configuration (dimensions, mine count)."
      };
    }
    sessionActive = true;
    currentAdapter = adapter;
    sessionGameCount = 0;
    currentSettings = await getEffectiveSettings();
    mlog("Session started, board:", boardConfig.cols, "x", boardConfig.rows, ", settings:", currentSettings);
    setupBoardChangeWatcher(adapter);
    startBoardPresenceMonitor(adapter);
    startNextGame(adapter);
    return { success: true };
  }
  function handleStopSession() {
    mlog("Stopping session");
    sessionActive = false;
    stopBoardPresenceMonitor();
    cancelAllWatchers(currentAdapter);
    if (recorder && recorder.getState() === "recording") {
      recorder.abort();
      const data = recorder.getRecordingData();
      if (data) {
        const mines = currentAdapter?.getMinePositions?.("unknown") ?? [];
        if (mines.length > 0) data.minePositions = mines;
        saveRecordingData(data);
      }
    } else if (recorder) {
      recorder.abort();
    }
    recorder = null;
    currentState = "idle";
  }
  function startBoardPresenceMonitor(adapter) {
    stopBoardPresenceMonitor();
    lastKnownBoardElement = adapter.findBoardElement();
    const intervalMS = BOARD_POLL_INTERVAL_MS;
    boardPresenceInterval = setInterval(() => {
      if (!isContextValid()) {
        teardownOnInvalidContext();
        return;
      }
      if (!sessionActive) return;
      const currentBoardElement = adapter.findBoardElement();
      const hadBoard = lastKnownBoardElement !== null;
      const hasBoard = currentBoardElement !== null && adapter.getBoardConfig() !== null;
      const elementReplaced = hadBoard && hasBoard && currentBoardElement !== lastKnownBoardElement && !document.contains(lastKnownBoardElement);
      if (elementReplaced) {
        handleBoardElementReplaced(adapter, currentBoardElement);
      } else if (!hasBoard && hadBoard) {
        handleBoardDisappeared(adapter);
      } else if (hasBoard && !hadBoard) {
        handleBoardAppeared(adapter, currentBoardElement);
      }
    }, intervalMS);
  }
  function handleBoardElementReplaced(adapter, newElement) {
    mlog("Board presence: element replaced (difficulty change or page update)");
    lastKnownBoardElement = newElement;
    if (recorder) {
      recorder.abort();
      recorder = null;
    }
    cancelAllWatchers(adapter);
    setupBoardChangeWatcher(adapter);
    startNextGame(adapter);
  }
  function handleBoardDisappeared(adapter) {
    mlog("Board presence: board disappeared (SPA navigation away from game)");
    lastKnownBoardElement = null;
    abortAndSaveRecorder();
    cancelAllWatchers(adapter);
    currentState = "ready";
  }
  function handleBoardAppeared(adapter, element) {
    mlog("Board presence: board appeared (SPA navigation to game)");
    lastKnownBoardElement = element;
    setupBoardChangeWatcher(adapter);
    startNextGame(adapter);
  }
  function stopBoardPresenceMonitor() {
    if (boardPresenceInterval !== null) {
      clearInterval(boardPresenceInterval);
      boardPresenceInterval = null;
    }
  }
  function setupBoardChangeWatcher(adapter) {
    adapter.onBoardChange?.(() => {
      if (!sessionActive) return;
      mlog("onBoardChange fired (childList mutation on board)");
      if (recorder) {
        recorder.abort();
        recorder = null;
      }
      adapter.cancelBoardReset?.();
      adapter.cancelGameEnd?.();
      lastKnownBoardElement = adapter.findBoardElement();
      startNextGame(adapter);
    });
  }
  function setupGameEndHandler(adapter) {
    adapter.onGameEnd?.((result) => {
      if (recorder && recorder.getState() === "recording") {
        mlog("Game end detected:", result);
        const finishedData = recorder.finishAndReset(result, buildReplayMetadata());
        if (finishedData) {
          finishedData.metadata.url = adapter.getGameURL?.() ?? finishedData.metadata.url;
        }
        currentState = "ready";
        setupGameEndHandler(adapter);
        adapter.cancelBoardReset?.();
        adapter.onBoardReset?.(() => {
          mlog("Board reset detected \u2192 unfreezing recorder");
          if (recorder) {
            recorder.unfreeze();
          }
        });
        if (finishedData) {
          setTimeout(() => {
            readMinesAndSave(adapter, finishedData, result, 0);
          }, 0);
        }
      } else {
        mwarn(
          "Game end callback fired but recorder state is",
          recorder?.getState() ?? "null",
          "\u2014 re-registering observer"
        );
        setupGameEndHandler(adapter);
      }
    });
  }
  function startNextGame(adapter) {
    if (recorder) {
      mlog("startNextGame: recorder already active, skipping");
      return;
    }
    mlog("startNextGame called");
    const boardElement = adapter.findBoardElement();
    const boardConfig = adapter.getBoardConfig();
    if (!boardElement || !boardConfig) {
      mwarn("startNextGame: board not found, waiting for presence monitor");
      currentState = "ready";
      return;
    }
    mlog("startNextGame: board", boardConfig.cols, "x", boardConfig.rows, ", squareSize", boardConfig.squareSize);
    recorder = new GameRecorder({
      board: boardConfig,
      metadata: buildReplayMetadata(),
      mouseTrackerConfig: {
        boardElement,
        squareSize: boardConfig.squareSize,
        keyboardMouse: currentSettings?.keyboardMouse,
        borderElement: adapter.findBorderElement?.() ?? void 0
      },
      onStateChange: (state) => {
        mlog("Recorder state changed:", state);
        if (sessionActive && state === "finished") return;
        currentState = state;
      }
    });
    setupGameEndHandler(adapter);
    recorder.start();
    currentState = "ready";
    mlog("Recorder started, state = ready, waiting for first click");
  }
  var MINE_READ_MAX_RETRIES = 4;
  var MINE_READ_DELAY_MS = 150;
  function readMinesAndSave(adapter, data, result, attempt) {
    const mines = adapter.getMinePositions?.(result) ?? [];
    if (mines.length > 0) {
      mlog(`Found ${mines.length} mines (attempt ${attempt + 1})`);
      data.minePositions = mines;
      saveRecordingData(data);
      return;
    }
    if (attempt < MINE_READ_MAX_RETRIES) {
      setTimeout(
        () => readMinesAndSave(adapter, data, result, attempt + 1),
        MINE_READ_DELAY_MS
      );
      return;
    }
    mwarn(`Could not read mine positions after ${attempt + 1} attempts`);
    saveRecordingData(data);
  }
  async function saveRecordingData(data) {
    if (data.totalTimeMs <= 0) {
      mlog("Skipping save: 0-duration replay");
      return;
    }
    let prefs;
    try {
      prefs = await browser_default.storage.local.get("winsOnly");
    } catch {
      teardownOnInvalidContext();
      return;
    }
    if (prefs.winsOnly === true && data.result !== "won") {
      mlog(`Skipping save (result=${data.result}, winsOnly=true)`);
      sessionGameCount++;
      return;
    }
    data.board.mines = data.minePositions.length;
    const rawvf = generateRawvf(data);
    const filename = generateFilename(data);
    sessionGameCount++;
    mlog(`Saved: ${filename} (${data.board.mines} mines, ${data.result})`);
    saveGame({
      filename,
      timestamp: data.metadata.timestamp ?? (/* @__PURE__ */ new Date()).toISOString(),
      cols: data.board.cols,
      rows: data.board.rows,
      mines: data.board.mines,
      result: data.result,
      timeMs: data.totalTimeMs,
      levelCode: data.metadata.levelCode
    }, rawvf).catch((err) => merr("Failed to save replay:", err));
  }
  function getEffectivePlayerName() {
    return playerName || currentAdapter?.getPlayerName?.() || void 0;
  }
  function buildReplayMetadata() {
    return {
      program: currentAdapter.getProgramName(),
      version: currentAdapter.getVersion?.(),
      url: currentAdapter.getGameURL?.() ?? void 0,
      player: getEffectivePlayerName(),
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      questionMarks: false,
      chordingMode: currentSettings?.chording,
      levelCode: currentAdapter?.getGameLevel?.() ?? void 0
    };
  }
  function getStatus() {
    let adapter = currentAdapter;
    if (!adapter) {
      const candidate = new MinesweeperOnlineSite();
      if (candidate.matches()) adapter = candidate;
    }
    const detectedName = adapter?.getPlayerName?.() || void 0;
    return {
      state: currentState,
      gameCount: sessionGameCount,
      eventCount: recorder?.getEventCount() ?? 0,
      elapsedMs: recorder?.getElapsedMs() ?? 0,
      detectedPlayerName: detectedName
    };
  }
  var navigationGeneration = 0;
  function handleNavigationDuringSession(adapter) {
    const generation = ++navigationGeneration;
    mlog("Navigation handler: URL changed during active session, generation =", generation);
    const boardElement = adapter.findBoardElement();
    if (boardElement && boardElement === lastKnownBoardElement && document.contains(boardElement)) {
      if (recorder && recorder.getState() === "recording") {
        mlog("Navigation handler: URL changed while recording \u2192 mid-game reset, discarding replay");
        recorder.finishAndReset("unknown", buildReplayMetadata());
        recorder.unfreeze();
        currentState = "ready";
        return;
      }
      mlog("Navigation handler: same board element \u2192 no-op (lifecycle handled by face observer)");
      return;
    }
    mlog("Navigation handler: board element changed or gone \u2192 full re-init");
    abortAndSaveRecorder();
    cancelAllWatchers(adapter);
    lastKnownBoardElement = null;
    currentState = "ready";
    if (adapter.isGamePage && !adapter.isGamePage()) {
      mlog("Navigation handler: non-game page, skipping board search");
      return;
    }
    let attempts = 0;
    const MAX_ATTEMPTS = 6;
    const RETRY_DELAY_MS = 250;
    const tryReInitialize = () => {
      if (generation !== navigationGeneration) return;
      if (!sessionActive || !currentAdapter) return;
      const boardElement2 = currentAdapter.findBoardElement();
      const boardConfig = currentAdapter.getBoardConfig();
      if (boardElement2 && boardConfig) {
        mlog(
          "Navigation handler: board found after URL change, re-initializing",
          boardConfig.cols,
          "x",
          boardConfig.rows
        );
        lastKnownBoardElement = boardElement2;
        setupBoardChangeWatcher(currentAdapter);
        startNextGame(currentAdapter);
      } else if (attempts < MAX_ATTEMPTS) {
        attempts++;
        mlog("Navigation handler: board not found yet, retry", attempts, "/", MAX_ATTEMPTS);
        setTimeout(tryReInitialize, RETRY_DELAY_MS);
      } else {
        mlog("Navigation handler: no board found after", MAX_ATTEMPTS, "retries (navigated away from game?)");
        lastKnownBoardElement = null;
        currentState = "ready";
      }
    };
    setTimeout(tryReInitialize, 150);
  }
  var lastPathname = window.location.pathname;
  async function persistAutoDetectedSettings(settings) {
    try {
      await saveAutoDetectedSettings(settings);
      currentSettings = await getEffectiveSettings();
    } catch {
      teardownOnInvalidContext();
    }
  }
  function startNavigationMonitor() {
    const adapter = new MinesweeperOnlineSite();
    if (!adapter.matches()) return;
    settingsBridgeAdapter = adapter;
    adapter.initSettingsBridge?.((settings) => {
      mlog("Settings from localStorage bridge:", settings);
      persistAutoDetectedSettings(settings);
    });
    navigationMonitorInterval = setInterval(() => {
      if (!isContextValid()) {
        teardownOnInvalidContext();
        return;
      }
      const currentPath = window.location.pathname;
      if (currentPath === lastPathname) return;
      const previousPath = lastPathname;
      lastPathname = currentPath;
      mlog(`SPA navigation: ${previousPath} \u2192 ${currentPath}`);
      if (sessionActive && currentAdapter) {
        handleNavigationDuringSession(currentAdapter);
      } else if (!sessionActive) {
        checkAlwaysRecord();
      }
    }, URL_POLL_INTERVAL_MS);
  }
  startNavigationMonitor();
  checkAlwaysRecord();
  async function checkAlwaysRecord() {
    let prefs;
    try {
      prefs = await browser_default.storage.local.get(["alwaysRecord", "playerName"]);
    } catch {
      teardownOnInvalidContext();
      return;
    }
    if (prefs.alwaysRecord === true && !sessionActive) {
      playerName = typeof prefs.playerName === "string" && prefs.playerName.trim() ? prefs.playerName.trim() : void 0;
      mlog("Always-record enabled, auto-starting session");
      const result = await handleStartSession();
      if (!result.success) {
        mlog(
          "Always-record: session start failed:",
          result.error,
          "\u2014 will retry on next SPA navigation"
        );
      }
    }
  }
  browser_default.storage.onChanged.addListener((changes, area) => {
    if (!isContextValid()) {
      teardownOnInvalidContext();
      return;
    }
    if (area !== "local") return;
    if (changes.playerName) {
      const newName = typeof changes.playerName.newValue === "string" && changes.playerName.newValue.trim() ? changes.playerName.newValue.trim() : void 0;
      playerName = newName;
    }
    if (changes.alwaysRecord?.newValue === true && !sessionActive) {
      mlog("Always-record toggled on, auto-starting session");
      checkAlwaysRecord();
    }
  });
  function handleWomReplayData(data) {
    try {
      const { recording, gameId } = convertWomReplay(data);
      const effectivePlayer = getEffectivePlayerName();
      if (effectivePlayer) {
        recording.metadata.player = effectivePlayer;
      }
      const rawvf = generateRawvf(recording);
      const filename = generateFilename(recording);
      mlog(`WoM converter: saved game ${gameId} as ${filename}`);
      saveGame({
        filename,
        timestamp: recording.metadata.timestamp ?? (/* @__PURE__ */ new Date()).toISOString(),
        cols: recording.board.cols,
        rows: recording.board.rows,
        mines: recording.board.mines,
        result: recording.result,
        timeMs: recording.totalTimeMs,
        levelCode: recording.metadata.levelCode
      }, rawvf).catch((err) => merr("Failed to save converted replay:", err));
      return { success: true, gameId };
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : String(err);
      mwarn("WoM converter error:", errorMsg);
      return { success: false, error: errorMsg };
    }
  }
})();
//# sourceMappingURL=index.js.map
