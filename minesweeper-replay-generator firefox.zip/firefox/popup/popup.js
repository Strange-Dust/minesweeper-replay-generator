"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/utils/browser.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill(), 1);
  var browser_default = import_webextension_polyfill.default;

  // src/utils/log.ts
  function timestamp() {
    return (/* @__PURE__ */ new Date()).toISOString();
  }
  var PREFIX = "[MSR";
  var minfo = (...args) => console.info(`${PREFIX} ${timestamp()}]`, ...args);
  var merr = (...args) => console.error(`${PREFIX} ${timestamp()}]`, ...args);

  // src/types/settings.ts
  var DEFAULT_SETTINGS = {
    chording: "both",
    keyboardMouse: {
      enabled: false,
      leftKeyCode: 32,
      // Space
      rightKeyCode: 32
      // Space
    }
  };

  // src/storage/settingsStorage.ts
  var SETTINGS_KEY = "gameSettings";
  async function loadSettings() {
    const data = await browser_default.storage.local.get(SETTINGS_KEY);
    const stored = data[SETTINGS_KEY];
    if (stored) {
      return stored;
    }
    return {
      autoDetectedSettings: null,
      manualSettings: null,
      manualOverride: false,
      lastUpdated: ""
    };
  }
  async function saveManualSettings(settings) {
    const current = await loadSettings();
    const stored = {
      ...current,
      manualSettings: settings,
      manualOverride: true,
      lastUpdated: (/* @__PURE__ */ new Date()).toISOString()
    };
    await browser_default.storage.local.set({ [SETTINGS_KEY]: stored });
    minfo("Manual settings saved:", settings.chording, "| keyboard:", settings.keyboardMouse.enabled);
  }
  async function clearManualOverride() {
    const current = await loadSettings();
    const stored = {
      ...current,
      manualOverride: false,
      lastUpdated: (/* @__PURE__ */ new Date()).toISOString()
    };
    await browser_default.storage.local.set({ [SETTINGS_KEY]: stored });
    minfo("Manual override disabled, reverting to auto-detected settings");
  }

  // src/storage/gameStorage.ts
  var META_KEY = "replayMeta";
  var CONTENT_KEY_PREFIX = "replay_";
  var STORAGE_BUDGET_BYTES = 50 * 1024 * 1024;
  async function loadMeta() {
    const data = await browser_default.storage.local.get(META_KEY);
    return data[META_KEY] ?? [];
  }
  async function getGamesContent(ids, allMeta) {
    const keys = ids.map((id) => `${CONTENT_KEY_PREFIX}${id}`);
    const data = await browser_default.storage.local.get(keys);
    const meta = allMeta ?? await loadMeta();
    const metaById = new Map(meta.map((m) => [m.id, m]));
    const results = [];
    for (const id of ids) {
      const rawvf = data[`${CONTENT_KEY_PREFIX}${id}`];
      const gameMeta = metaById.get(id);
      if (rawvf && gameMeta) {
        results.push({ filename: gameMeta.filename, rawvf });
      }
    }
    return results;
  }
  async function deleteGames(ids) {
    const idSet = new Set(ids);
    const allMeta = await loadMeta();
    const remaining = allMeta.filter((g) => !idSet.has(g.id));
    await browser_default.storage.local.set({ [META_KEY]: remaining });
    await browser_default.storage.local.remove(
      ids.map((id) => `${CONTENT_KEY_PREFIX}${id}`)
    );
    minfo(`Deleted ${ids.length} replay(s), ${remaining.length} remaining`);
  }
  async function clearAllGames() {
    const allMeta = await loadMeta();
    const contentKeys = allMeta.map((g) => `${CONTENT_KEY_PREFIX}${g.id}`);
    await browser_default.storage.local.remove([META_KEY, ...contentKeys]);
    minfo(`Cleared all replays (${allMeta.length} removed)`);
  }

  // src/utils/zip.ts
  var CRC_TABLE = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let j = 0; j < 8; j++) {
      c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
    }
    CRC_TABLE[i] = c;
  }
  function crc32(data) {
    let crc = 4294967295;
    for (let i = 0; i < data.length; i++) {
      crc = CRC_TABLE[(crc ^ data[i]) & 255] ^ crc >>> 8;
    }
    return (crc ^ 4294967295) >>> 0;
  }
  function createZipBlob(entries) {
    const encoder = new TextEncoder();
    const parts = [];
    const records = [];
    let offset = 0;
    for (const entry of entries) {
      const nameBytes = encoder.encode(entry.filename);
      const dataBytes = encoder.encode(entry.content);
      const crc = crc32(dataBytes);
      records.push({ nameBytes, dataBytes, crc, offset });
      const header = new ArrayBuffer(30);
      const hv = new DataView(header);
      hv.setUint32(0, 67324752, true);
      hv.setUint16(4, 20, true);
      hv.setUint16(6, 2048, true);
      hv.setUint16(8, 0, true);
      hv.setUint16(10, 0, true);
      hv.setUint16(12, 0, true);
      hv.setUint32(14, crc, true);
      hv.setUint32(18, dataBytes.length, true);
      hv.setUint32(22, dataBytes.length, true);
      hv.setUint16(26, nameBytes.length, true);
      hv.setUint16(28, 0, true);
      parts.push(new Uint8Array(header));
      parts.push(nameBytes);
      parts.push(dataBytes);
      offset += 30 + nameBytes.length + dataBytes.length;
    }
    const centralDirOffset = offset;
    let centralDirSize = 0;
    for (const record of records) {
      const entry = new ArrayBuffer(46);
      const ev = new DataView(entry);
      ev.setUint32(0, 33639248, true);
      ev.setUint16(4, 20, true);
      ev.setUint16(6, 20, true);
      ev.setUint16(8, 2048, true);
      ev.setUint16(10, 0, true);
      ev.setUint16(12, 0, true);
      ev.setUint16(14, 0, true);
      ev.setUint32(16, record.crc, true);
      ev.setUint32(20, record.dataBytes.length, true);
      ev.setUint32(24, record.dataBytes.length, true);
      ev.setUint16(28, record.nameBytes.length, true);
      ev.setUint16(30, 0, true);
      ev.setUint16(32, 0, true);
      ev.setUint16(34, 0, true);
      ev.setUint16(36, 0, true);
      ev.setUint32(38, 0, true);
      ev.setUint32(42, record.offset, true);
      parts.push(new Uint8Array(entry));
      parts.push(record.nameBytes);
      centralDirSize += 46 + record.nameBytes.length;
    }
    const endRecord = new ArrayBuffer(22);
    const endView = new DataView(endRecord);
    endView.setUint32(0, 101010256, true);
    endView.setUint16(4, 0, true);
    endView.setUint16(6, 0, true);
    endView.setUint16(8, records.length, true);
    endView.setUint16(10, records.length, true);
    endView.setUint32(12, centralDirSize, true);
    endView.setUint32(16, centralDirOffset, true);
    endView.setUint16(20, 0, true);
    parts.push(new Uint8Array(endRecord));
    return new Blob(parts, { type: "application/zip" });
  }

  // src/utils/format.ts
  function formatDateForFilename(timestamp2) {
    try {
      const date = timestamp2 ? new Date(timestamp2) : /* @__PURE__ */ new Date();
      return date.toISOString().replace(/[-:T]/g, "").replace(/\.\d+Z$/, "").replace(/(\d{8})(\d{6})/, "$1_$2");
    } catch {
      return "unknown";
    }
  }

  // src/popup/popup.ts
  var ANALYZER_URL = "https://strange-dust.github.io/minesweeper-replay-analyzer/";
  var statusText = document.getElementById("status-text");
  var liveStats = document.getElementById("live-stats");
  var btnStart = document.getElementById("btn-start");
  var btnStop = document.getElementById("btn-stop");
  var selectAllBtn = document.getElementById("select-all");
  var selectWinsBtn = document.getElementById("select-wins");
  var selectWinsGroup = document.getElementById("select-wins-group");
  var selectionActions = document.getElementById("selection-actions");
  var storageInfoEl = document.getElementById("storage-info");
  var gameListEl = document.getElementById("game-list");
  var btnDownload = document.getElementById("btn-download");
  var btnDelete = document.getElementById("btn-delete");
  var btnClearAll = document.getElementById("btn-clear-all");
  var playerNameInput = document.getElementById("player-name");
  var winsOnlyCheckbox = document.getElementById("wins-only");
  var alwaysRecordCheckbox = document.getElementById("always-record");
  var alwaysAnalyzeCheckbox = document.getElementById("always-analyze");
  var settingsStatusEl = document.getElementById("settings-status");
  var settingsStatusText = document.getElementById("settings-status-text");
  var chordingDisplay = document.getElementById("chording-display");
  var keyboardDisplay = document.getElementById("keyboard-display");
  var manualOverride = document.getElementById("manual-override");
  var manualSettingsEl = document.getElementById("manual-settings");
  var chordingSelect = document.getElementById("chording-select");
  var keyboardEnabled = document.getElementById("keyboard-enabled");
  var keyboardKeysEl = document.getElementById("keyboard-keys");
  var leftKeySelect = document.getElementById("left-key");
  var rightKeySelect = document.getElementById("right-key");
  var autoCaptureRow = document.getElementById("auto-capture-row");
  var btnCaptureToggle = document.getElementById("btn-capture-toggle");
  var captureStatus = document.getElementById("capture-status");
  var pasteInput = document.getElementById("paste-input");
  var btnConvert = document.getElementById("btn-convert");
  var convertStatus = document.getElementById("convert-status");
  var games = [];
  var selectedIds = /* @__PURE__ */ new Set();
  var lastSessionGameCount = 0;
  var pollingInterval = null;
  async function init() {
    const prefs = await browser_default.storage.local.get(["playerName", "winsOnly", "alwaysRecord", "alwaysAnalyze"]);
    if (prefs.playerName && typeof prefs.playerName === "string") {
      playerNameInput.value = prefs.playerName;
    }
    winsOnlyCheckbox.checked = prefs.winsOnly === true;
    alwaysRecordCheckbox.checked = prefs.alwaysRecord === true;
    alwaysAnalyzeCheckbox.checked = prefs.alwaysAnalyze === true;
    updateAlwaysRecordUI(prefs.alwaysRecord === true);
    playerNameInput.addEventListener("input", () => {
      browser_default.storage.local.set({ playerName: playerNameInput.value });
    });
    winsOnlyCheckbox.addEventListener("change", () => {
      browser_default.storage.local.set({ winsOnly: winsOnlyCheckbox.checked });
      updateSelectWinsVisibility();
    });
    alwaysRecordCheckbox.addEventListener("change", () => {
      const enabled = alwaysRecordCheckbox.checked;
      browser_default.storage.local.set({ alwaysRecord: enabled });
      updateAlwaysRecordUI(enabled);
    });
    alwaysAnalyzeCheckbox.addEventListener("change", () => {
      browser_default.storage.local.set({ alwaysAnalyze: alwaysAnalyzeCheckbox.checked });
    });
    btnStart.addEventListener("click", startRecording);
    btnStop.addEventListener("click", stopRecording);
    btnDownload.addEventListener("click", downloadSelected);
    btnDelete.addEventListener("click", deleteSelected);
    btnClearAll.addEventListener("click", clearAll);
    selectAllBtn.addEventListener("click", onSelectAllClick);
    selectWinsBtn.addEventListener("click", onSelectWinsClick);
    populateKeySelects();
    manualOverride.addEventListener("change", onManualOverrideChange);
    chordingSelect.addEventListener("change", onManualSettingChange);
    keyboardEnabled.addEventListener("change", onKeyboardEnabledChange);
    leftKeySelect.addEventListener("change", onManualSettingChange);
    rightKeySelect.addEventListener("change", onManualSettingChange);
    btnCaptureToggle.addEventListener("click", toggleCapture);
    btnConvert.addEventListener("click", convertPaste);
    pasteInput.addEventListener("input", () => {
      btnConvert.disabled = pasteInput.value.trim().length === 0;
    });
    updateSelectWinsVisibility();
    await Promise.all([
      refreshGameList(),
      refreshStatus(),
      refreshSettings(),
      refreshCaptureStatus()
    ]);
    browser_default.storage.onChanged.addListener((changes, area) => {
      if (area !== "local" || !changes.replayMeta) return;
      refreshGameList();
    });
  }
  async function sendToContentScript(message) {
    const [tab] = await browser_default.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return null;
    try {
      return await browser_default.tabs.sendMessage(tab.id, message);
    } catch {
      return null;
    }
  }
  function updateAlwaysRecordUI(enabled) {
    btnStart.classList.toggle("hidden", enabled);
    btnStop.classList.toggle("hidden", enabled);
  }
  async function startRecording() {
    const playerName = playerNameInput.value.trim() || void 0;
    const response = await sendToContentScript({ type: "START_RECORDING", playerName });
    if (response?.error) {
      merr("Start failed:", response.error);
    }
    lastSessionGameCount = 0;
    startPolling();
    await refreshStatus();
  }
  async function stopRecording() {
    await sendToContentScript({ type: "STOP_RECORDING" });
    stopPolling();
    await refreshStatus();
    await refreshGameList();
  }
  async function refreshStatus() {
    const response = await sendToContentScript({ type: "GET_STATUS" });
    updateRecordingUI(response);
    if (response?.detectedPlayerName && !playerNameInput.value.trim()) {
      playerNameInput.placeholder = response.detectedPlayerName;
    }
    if (response && response.gameCount > lastSessionGameCount) {
      lastSessionGameCount = response.gameCount;
      await refreshGameList();
    }
  }
  var POLL_INTERVAL_MS = 500;
  function startPolling() {
    if (pollingInterval) return;
    pollingInterval = setInterval(refreshStatus, POLL_INTERVAL_MS);
  }
  function stopPolling() {
    if (pollingInterval) {
      clearInterval(pollingInterval);
      pollingInterval = null;
    }
  }
  async function refreshGameList() {
    games = await loadMeta();
    const gameIds = new Set(games.map((g) => g.id));
    for (const id of selectedIds) {
      if (!gameIds.has(id)) selectedIds.delete(id);
    }
    renderGameList();
    updateStorageInfo();
    updateActionButtons();
  }
  function renderGameList() {
    if (games.length === 0) {
      gameListEl.innerHTML = '<div class="empty-state">No recorded games yet</div>';
      selectionActions.classList.add("hidden");
      return;
    }
    selectionActions.classList.remove("hidden");
    const sorted = [...games].reverse();
    gameListEl.innerHTML = sorted.map((game) => {
      const checked = selectedIds.has(game.id) ? "checked" : "";
      const level = getLevelDisplay(game.cols, game.rows, game.mines, game.levelCode);
      const result = formatResult(game.result);
      const time = formatGameTime(game.timeMs);
      const size = formatSize(game.sizeBytes);
      const date = formatDate(game.timestamp);
      return `<div class="game-item" data-id="${escapeAttr(game.id)}">
      <input type="checkbox" ${checked} />
      <div class="game-details">
        <div class="game-row-main">
          <span class="game-result ${game.result}">${result}</span>
          <span class="game-level">${level}</span>
          <span class="game-time">${time}</span>
          <span class="game-size">${size}</span>
        </div>
        <div class="game-row-date">${date}</div>
      </div>
      <button class="btn-analyze" data-id="${escapeAttr(game.id)}" title="Send to Analyzer"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3h7v7"/><path d="M13 3L3 13"/></svg></button>
    </div>`;
    }).join("");
    gameListEl.querySelectorAll(".game-item").forEach((item) => {
      item.addEventListener("click", (e) => {
        if (e.target.closest(".btn-analyze")) return;
        const cb = item.querySelector('input[type="checkbox"]');
        if (cb && e.target !== cb) cb.checked = !cb.checked;
        cb?.dispatchEvent(new Event("change", { bubbles: true }));
      });
    });
    gameListEl.querySelectorAll('input[type="checkbox"]').forEach((cb) => {
      cb.addEventListener("change", onItemCheckboxChange);
    });
    gameListEl.querySelectorAll(".btn-analyze").forEach((btn) => {
      btn.addEventListener("click", onAnalyzeClick);
    });
  }
  function onItemCheckboxChange(e) {
    const checkbox = e.target;
    const item = checkbox.closest(".game-item");
    const id = item?.dataset.id;
    if (!id) return;
    if (checkbox.checked) {
      selectedIds.add(id);
    } else {
      selectedIds.delete(id);
    }
    updateSelectAllState();
    updateActionButtons();
  }
  function onSelectAllClick() {
    const allSelected = games.length > 0 && games.every((g) => selectedIds.has(g.id));
    if (allSelected) {
      selectedIds.clear();
    } else {
      games.forEach((g) => selectedIds.add(g.id));
    }
    syncCheckboxes();
    updateSelectAllState();
    updateActionButtons();
  }
  function onSelectWinsClick() {
    selectedIds.clear();
    games.filter((g) => g.result === "won").forEach((g) => selectedIds.add(g.id));
    syncCheckboxes();
    updateSelectAllState();
    updateActionButtons();
  }
  function syncCheckboxes() {
    gameListEl.querySelectorAll('input[type="checkbox"]').forEach((cb) => {
      const item = cb.closest(".game-item");
      const id = item?.dataset.id;
      if (id) cb.checked = selectedIds.has(id);
    });
  }
  function updateSelectAllState() {
    if (games.length === 0) {
      selectAllBtn.textContent = "Select all";
      return;
    }
    const allSelected = games.every((g) => selectedIds.has(g.id));
    selectAllBtn.textContent = allSelected ? "Select none" : "Select all";
  }
  function updateSelectWinsVisibility() {
    selectWinsGroup.classList.toggle("hidden", winsOnlyCheckbox.checked);
  }
  async function downloadSelected() {
    const ids = selectedIds.size > 0 ? [...selectedIds] : games.map((g) => g.id);
    if (ids.length === 0) return;
    const contents = await getGamesContent(ids, games);
    if (contents.length === 0) return;
    if (contents.length === 1) {
      const game = contents[0];
      const blob = new Blob([game.rawvf], { type: "text/plain" });
      triggerDownload(blob, game.filename);
      minfo("Downloaded replay:", game.filename);
    } else {
      const zipBlob = createZipBlob(
        contents.map((g) => ({ filename: g.filename, content: g.rawvf }))
      );
      const dateStr = formatDateForFilename();
      const zipName = `minesweeper_replays_${dateStr}.zip`;
      triggerDownload(zipBlob, zipName);
      minfo(`Downloaded ${contents.length} replays as ${zipName}`);
    }
  }
  function onAnalyzeClick(e) {
    e.preventDefault();
    e.stopPropagation();
    const btn = e.currentTarget;
    const id = btn.dataset.id;
    if (id) sendToAnalyzer(id);
  }
  async function sendToAnalyzer(gameId) {
    const contents = await getGamesContent([gameId], games);
    if (contents.length === 0) return;
    const { rawvf, filename } = contents[0];
    minfo("Sending to analyzer:", filename);
    sendToBackground({
      type: "SEND_TO_ANALYZER",
      rawvf,
      filename,
      analyzerUrl: ANALYZER_URL
    }).catch(() => {
    });
  }
  async function deleteSelected() {
    if (selectedIds.size === 0) return;
    const count = selectedIds.size;
    const confirmed = confirm(
      `Delete ${count} replay${count > 1 ? "s" : ""}? This cannot be undone.`
    );
    if (!confirmed) return;
    await deleteGames([...selectedIds]);
    minfo(`Deleted ${count} replay(s)`);
    selectedIds.clear();
    await refreshGameList();
  }
  async function clearAll() {
    if (games.length === 0) return;
    const confirmed = confirm(
      `Delete ALL ${games.length} replay${games.length > 1 ? "s" : ""}? This cannot be undone.`
    );
    if (!confirmed) return;
    await clearAllGames();
    minfo("Cleared all replays");
    selectedIds.clear();
    await refreshGameList();
  }
  function triggerDownload(blob, filename) {
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    anchor.click();
    URL.revokeObjectURL(url);
  }
  function updateRecordingUI(status) {
    if (!status) {
      statusText.textContent = "Unavailable";
      statusText.className = "status unavailable";
      liveStats.textContent = "Navigate to a supported minesweeper site";
      btnStart.disabled = true;
      btnStop.disabled = true;
      return;
    }
    statusText.textContent = capitalize(status.state);
    statusText.className = `status ${status.state}`;
    if (status.state === "recording") {
      const time = formatGameTime(status.elapsedMs ?? 0);
      liveStats.textContent = `${status.eventCount} events \xB7 ${time}`;
    } else if (status.state === "ready") {
      liveStats.textContent = status.gameCount > 0 ? `${status.gameCount} game${status.gameCount > 1 ? "s" : ""} this session` : "Waiting for first click\u2026";
    } else {
      liveStats.textContent = "";
    }
    btnStart.disabled = status.state === "recording" || status.state === "ready";
    btnStop.disabled = status.state !== "recording" && status.state !== "ready";
    if (status.state === "recording" || status.state === "ready") {
      startPolling();
    } else {
      stopPolling();
    }
  }
  function updateStorageInfo() {
    const usedBytes = games.reduce((sum, g) => sum + g.sizeBytes, 0);
    storageInfoEl.textContent = `${formatSize(usedBytes)} / ${formatSize(STORAGE_BUDGET_BYTES)}`;
  }
  function updateActionButtons() {
    const selCount = selectedIds.size;
    const hasGames = games.length > 0;
    btnDownload.disabled = !hasGames;
    btnDelete.disabled = selCount === 0;
    btnClearAll.disabled = !hasGames;
    if (selCount > 0) {
      btnDownload.textContent = `\u{1F4BE} Download (${selCount})`;
    } else if (hasGames) {
      btnDownload.textContent = `\u{1F4BE} Download All (${games.length})`;
    } else {
      btnDownload.textContent = "\u{1F4BE} Download";
    }
  }
  var LEVEL_CODE_DISPLAY = {
    1: "Beginner",
    2: "Intermediate",
    3: "Expert",
    4: "Custom",
    11: "Easy",
    12: "Medium",
    13: "Hard",
    14: "Evil",
    15: "Custom"
  };
  function getLevelDisplay(cols, rows, mines, levelCode) {
    if (levelCode != null) {
      const name = LEVEL_CODE_DISPLAY[levelCode];
      if (name) return name;
    }
    if (cols === 8 && rows === 8 && mines === 10) return "Beg";
    if (cols === 16 && rows === 16 && mines === 40) return "Int";
    if (cols === 30 && rows === 16 && mines === 99) return "Exp";
    return `${cols}x${rows}`;
  }
  function formatResult(result) {
    if (result === "won") return "Won";
    if (result === "lost") return "Lost";
    return "\u2014";
  }
  function formatGameTime(ms) {
    return `${(ms / 1e3).toFixed(3)}s`;
  }
  function formatSize(bytes) {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }
  function formatDate(isoString) {
    try {
      const d = new Date(isoString);
      const pad = (n) => String(n).padStart(2, "0");
      return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
    } catch {
      return "Unknown date";
    }
  }
  function capitalize(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
  }
  function escapeAttr(str) {
    return str.replace(/&/g, "&amp;").replace(/"/g, "&quot;");
  }
  var KEY_OPTIONS = [
    { code: 32, label: "Space" },
    { code: 17, label: "Ctrl" },
    { code: 18, label: "Alt" },
    { code: 65, label: "A" },
    { code: 66, label: "B" },
    { code: 67, label: "C" },
    { code: 68, label: "D" },
    { code: 69, label: "E" },
    { code: 70, label: "F" },
    { code: 71, label: "G" },
    { code: 72, label: "H" },
    { code: 73, label: "I" },
    { code: 74, label: "J" },
    { code: 75, label: "K" },
    { code: 76, label: "L" },
    { code: 77, label: "M" },
    { code: 78, label: "N" },
    { code: 79, label: "O" },
    { code: 80, label: "P" },
    { code: 81, label: "Q" },
    { code: 82, label: "R" },
    { code: 83, label: "S" },
    { code: 84, label: "T" },
    { code: 85, label: "U" },
    { code: 86, label: "V" },
    { code: 87, label: "W" },
    { code: 88, label: "X" },
    { code: 89, label: "Y" },
    { code: 90, label: "Z" }
  ];
  function populateKeySelects() {
    for (const select of [leftKeySelect, rightKeySelect]) {
      select.innerHTML = KEY_OPTIONS.map(
        (k) => `<option value="${k.code}">${k.label}</option>`
      ).join("");
    }
  }
  async function refreshSettings() {
    const stored = await loadSettings();
    updateSettingsUI(stored);
  }
  function updateSettingsUI(stored) {
    const isManual = stored.manualOverride;
    const hasAutoDetected = stored.autoDetectedSettings !== null;
    const effectiveSettings = isManual && stored.manualSettings ? stored.manualSettings : stored.autoDetectedSettings ?? DEFAULT_SETTINGS;
    if (isManual) {
      settingsStatusEl.className = "settings-status detected";
      settingsStatusText.textContent = hasAutoDetected ? "Manual override active (auto-detected settings saved)" : "Manual override active";
    } else if (hasAutoDetected) {
      settingsStatusEl.className = "settings-status detected";
      settingsStatusText.textContent = "Auto-detected from settings";
    } else {
      settingsStatusEl.className = "settings-status";
      settingsStatusText.textContent = "\u26A0\uFE0F Not detected \u2014 visit the game's settings page";
    }
    const summaryEl = document.getElementById("settings-summary");
    if (summaryEl) {
      summaryEl.textContent = hasAutoDetected || isManual ? "Game Settings" : "\u26A0\uFE0F Settings";
    }
    chordingDisplay.textContent = formatChordingMode(effectiveSettings.chording);
    keyboardDisplay.textContent = formatKeyboardConfig(effectiveSettings.keyboardMouse);
    manualOverride.checked = isManual;
    if (isManual) {
      manualSettingsEl.classList.remove("hidden");
      const manualValues = stored.manualSettings ?? effectiveSettings;
      chordingSelect.value = manualValues.chording;
      keyboardEnabled.checked = manualValues.keyboardMouse.enabled;
      leftKeySelect.value = String(manualValues.keyboardMouse.leftKeyCode);
      rightKeySelect.value = String(manualValues.keyboardMouse.rightKeyCode);
      keyboardKeysEl.classList.toggle("hidden", !manualValues.keyboardMouse.enabled);
    } else {
      manualSettingsEl.classList.add("hidden");
    }
  }
  function formatChordingMode(mode) {
    switch (mode) {
      case "superclick":
        return "Left click";
      case "both":
        return "Left+Right";
      case "disabled":
        return "Disabled";
    }
  }
  function formatKeyboardConfig(config) {
    if (!config.enabled) return "Disabled";
    const left = KEY_OPTIONS.find((k) => k.code === config.leftKeyCode)?.label ?? `Key ${config.leftKeyCode}`;
    const right = KEY_OPTIONS.find((k) => k.code === config.rightKeyCode)?.label ?? `Key ${config.rightKeyCode}`;
    return `Enabled (L: ${left}, R: ${right})`;
  }
  async function onManualOverrideChange() {
    if (manualOverride.checked) {
      const stored = await loadSettings();
      const seedSettings = stored.autoDetectedSettings ?? DEFAULT_SETTINGS;
      await saveManualSettings(seedSettings);
    } else {
      await clearManualOverride();
    }
    await refreshSettings();
  }
  async function onManualSettingChange() {
    if (!manualOverride.checked) return;
    await saveManualSettings(getManualSettingsFromUI());
    await refreshSettings();
  }
  function onKeyboardEnabledChange() {
    keyboardKeysEl.classList.toggle("hidden", !keyboardEnabled.checked);
    onManualSettingChange();
  }
  function getManualSettingsFromUI() {
    return {
      chording: chordingSelect.value,
      keyboardMouse: {
        enabled: keyboardEnabled.checked,
        leftKeyCode: parseInt(leftKeySelect.value, 10) || DEFAULT_SETTINGS.keyboardMouse.leftKeyCode,
        rightKeyCode: parseInt(rightKeySelect.value, 10) || DEFAULT_SETTINGS.keyboardMouse.rightKeyCode
      }
    };
  }
  async function sendToBackground(message) {
    try {
      return await browser_default.runtime.sendMessage(message);
    } catch {
      return null;
    }
  }
  async function getActiveTabId() {
    const [tab] = await browser_default.tabs.query({ active: true, currentWindow: true });
    return tab?.id ?? null;
  }
  async function refreshCaptureStatus() {
    const tabId = await getActiveTabId();
    if (!tabId) {
      autoCaptureRow.classList.add("hidden");
      return;
    }
    const response = await sendToBackground({
      type: "GET_WS_CAPTURE_STATUS",
      tabId
    });
    if (!response || !response.supported) {
      autoCaptureRow.classList.add("hidden");
      return;
    }
    autoCaptureRow.classList.remove("hidden");
    btnCaptureToggle.disabled = false;
    updateCaptureUI(response.active);
  }
  function updateCaptureUI(active) {
    if (active) {
      btnCaptureToggle.textContent = "\u23F9 Stop Capture";
      btnCaptureToggle.className = "btn btn-sm btn-danger";
      captureStatus.textContent = "Listening for replay data\u2026";
      captureStatus.className = "converter-status";
    } else {
      btnCaptureToggle.textContent = "\u25B6 Start Capture";
      btnCaptureToggle.className = "btn btn-sm btn-primary";
      captureStatus.textContent = "";
      captureStatus.className = "converter-status";
    }
  }
  async function toggleCapture() {
    const tabId = await getActiveTabId();
    if (!tabId) return;
    const status = await sendToBackground({
      type: "GET_WS_CAPTURE_STATUS",
      tabId
    });
    if (status?.active) {
      await sendToBackground({ type: "STOP_WS_CAPTURE", tabId });
      updateCaptureUI(false);
    } else {
      const result = await sendToBackground({ type: "START_WS_CAPTURE", tabId });
      if (result?.success) {
        updateCaptureUI(true);
      } else {
        captureStatus.textContent = "Failed to start capture";
        captureStatus.className = "converter-status error";
      }
    }
  }
  async function convertPaste() {
    const rawText = pasteInput.value.trim();
    if (!rawText) return;
    btnConvert.disabled = true;
    convertStatus.textContent = "Converting\u2026";
    convertStatus.className = "converter-status";
    const response = await sendToContentScript({
      type: "PARSE_WS_REPLAY",
      rawText
    });
    if (!response) {
      convertStatus.textContent = "Content script unavailable \u2014 navigate to minesweeper.online first";
      convertStatus.className = "converter-status error";
      btnConvert.disabled = false;
      return;
    }
    if (response.success) {
      convertStatus.textContent = `Saved! Game #${response.gameId ?? "unknown"}`;
      convertStatus.className = "converter-status success";
      minfo("Converted WoM replay, game #" + (response.gameId ?? "unknown"));
      pasteInput.value = "";
      btnConvert.disabled = true;
      await refreshGameList();
    } else {
      convertStatus.textContent = response.error ?? "Conversion failed";
      convertStatus.className = "converter-status error";
      btnConvert.disabled = false;
    }
  }
  init();
})();
//# sourceMappingURL=popup.js.map
