"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/utils/browser.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill(), 1);
  var browser_default = import_webextension_polyfill.default;

  // src/lib/utils/log.ts
  var LEVEL_RANK = {
    debug: 0,
    info: 1,
    warn: 2,
    error: 3,
    silent: 4
  };
  var currentLevel = "debug";
  var currentPrefix = "[MSR";
  function shouldLog(level) {
    return LEVEL_RANK[level] >= LEVEL_RANK[currentLevel];
  }
  function timestamp() {
    return (/* @__PURE__ */ new Date()).toISOString();
  }
  var mlog = (...args) => {
    if (shouldLog("debug")) console.debug(`${currentPrefix} ${timestamp()}]`, ...args);
  };
  var minfo = (...args) => {
    if (shouldLog("info")) console.info(`${currentPrefix} ${timestamp()}]`, ...args);
  };
  var mwarn = (...args) => {
    if (shouldLog("warn")) console.warn(`${currentPrefix} ${timestamp()}]`, ...args);
  };
  var merr = (...args) => {
    if (shouldLog("error")) console.error(`${currentPrefix} ${timestamp()}]`, ...args);
  };

  // src/lib/utils/socketIoParser.ts
  var SOCKETIO_EVENT_PREFIX = "42";
  var TARGET_EVENT_NAME = "response";
  var REPLAY_RESPONSE_CODE = 203;
  function parseSocketIoReplayFrame(payload) {
    if (!payload.startsWith(SOCKETIO_EVENT_PREFIX)) return null;
    const jsonStr = payload.slice(SOCKETIO_EVENT_PREFIX.length);
    let parsed;
    try {
      parsed = JSON.parse(jsonStr);
    } catch {
      return null;
    }
    if (!Array.isArray(parsed)) return null;
    if (parsed[0] !== TARGET_EVENT_NAME) return null;
    const responseArgs = parsed[1];
    if (!Array.isArray(responseArgs)) return null;
    if (responseArgs[1] !== REPLAY_RESPONSE_CODE) return null;
    const replayData = responseArgs[2];
    if (replayData == null) return null;
    return replayData;
  }

  // src/background/webSocketCapture.ts
  function getChromeDebugger() {
    try {
      if (typeof chrome === "undefined") return void 0;
      const api = chrome["debugger"];
      if (api && typeof api.attach === "function") {
        return api;
      }
      return void 0;
    } catch {
      return void 0;
    }
  }
  var WS_URL_PATTERN = /^wss:\/\/main\d*\.minesweeper\.online/;
  var CDP_VERSION = "1.3";
  var activeSessions = /* @__PURE__ */ new Map();
  function isWebSocketCaptureSupported() {
    return getChromeDebugger() !== void 0;
  }
  async function startCapture(tabId, callback) {
    if (!isWebSocketCaptureSupported()) {
      mwarn("WebSocket capture: not supported in this browser");
      return false;
    }
    if (activeSessions.has(tabId)) {
      mlog("WebSocket capture: already active for tab", tabId);
      return true;
    }
    try {
      const dbg = getChromeDebugger();
      await dbg.attach({ tabId }, CDP_VERSION);
      await dbg.sendCommand({ tabId }, "Network.enable");
      const session = {
        tabId,
        trackedRequestIds: /* @__PURE__ */ new Set(),
        callback
      };
      activeSessions.set(tabId, session);
      mlog("WebSocket capture: started for tab", tabId);
      return true;
    } catch (err) {
      merr("WebSocket capture: failed to start for tab", tabId, err);
      return false;
    }
  }
  async function stopCapture(tabId) {
    if (!activeSessions.has(tabId)) return;
    activeSessions.delete(tabId);
    try {
      await getChromeDebugger().detach({ tabId });
      mlog("WebSocket capture: stopped for tab", tabId);
    } catch {
    }
  }
  function isCaptureActive(tabId) {
    return activeSessions.has(tabId);
  }
  function handleDebuggerEvent(source, method, params) {
    const tabId = source.tabId;
    if (tabId == null) return;
    const session = activeSessions.get(tabId);
    if (!session) return;
    switch (method) {
      case "Network.webSocketCreated": {
        const url = params?.url;
        const requestId = params?.requestId;
        if (url && requestId && WS_URL_PATTERN.test(url)) {
          session.trackedRequestIds.add(requestId);
          mlog("WebSocket capture: tracking connection", url, "(requestId:", requestId + ")");
        }
        break;
      }
      case "Network.webSocketClosed": {
        const requestId = params?.requestId;
        if (requestId) {
          session.trackedRequestIds.delete(requestId);
        }
        break;
      }
      case "Network.webSocketFrameReceived": {
        const requestId = params?.requestId;
        if (!requestId || !session.trackedRequestIds.has(requestId)) break;
        const response = params?.response;
        const payloadData = response?.payloadData;
        if (!payloadData) break;
        const replayData = parseSocketIoReplayFrame(payloadData);
        if (replayData !== null) {
          mlog("WebSocket capture: replay data found in frame!");
          session.callback(tabId, replayData);
        }
        break;
      }
    }
  }
  function handleDebuggerDetach(source, reason) {
    const tabId = source.tabId;
    if (tabId == null) return;
    if (activeSessions.has(tabId)) {
      mlog("WebSocket capture: debugger detached for tab", tabId, "\u2014 reason:", reason);
      activeSessions.delete(tabId);
    }
  }
  function initWebSocketCapture() {
    const dbg = getChromeDebugger();
    if (!dbg) {
      mlog("WebSocket capture: not available (chrome.debugger API not present)");
      return;
    }
    dbg.onEvent.addListener(handleDebuggerEvent);
    dbg.onDetach.addListener(handleDebuggerDetach);
    mlog("WebSocket capture: CDP event listeners registered");
  }

  // src/background/index.ts
  var ANALYZER_URL = "https://strange-dust.github.io/minesweeper-replay-analyzer/";
  var REPLAY_LINK_DOMAINS = [
    "scoreganizer.net",
    "minesweepergame.com",
    "saolei.wang"
  ];
  var REPLAY_LINK_PATTERNS = REPLAY_LINK_DOMAINS.flatMap((d) => [
    `*://${d}/*`,
    `*://*.${d}/*`
  ]);
  var SUPPORTED_SITE_PATTERNS = [
    "https://minesweeper.online/*"
  ];
  browser_default.runtime.onInstalled.addListener((details) => {
    if (details.reason === "install") {
      mlog("Minesweeper Replay Generator installed.");
    } else if (details.reason === "update") {
      mlog(`Minesweeper Replay Generator updated to v${browser_default.runtime.getManifest().version}`);
    }
    injectIntoExistingTabs();
  });
  async function injectIntoExistingTabs() {
    try {
      const tabs = await browser_default.tabs.query({ url: SUPPORTED_SITE_PATTERNS });
      for (const tab of tabs) {
        if (!tab.id) continue;
        try {
          await browser_default.scripting.executeScript({
            target: { tabId: tab.id },
            files: ["content/index.js"]
          });
          mlog(`Injected content script into tab ${tab.id}: ${tab.url}`);
        } catch (err) {
          mwarn(`Could not inject into tab ${tab.id}:`, err);
        }
      }
    } catch (err) {
      mwarn("Could not query tabs:", err);
    }
  }
  browser_default.runtime.onMessage.addListener((message, sender) => {
    const msg = message;
    if (msg.type === "RECORDING_STATE_CHANGED") {
      updateBadge(msg.state ?? "idle", sender.tab?.id);
    }
    if (msg.type === "START_WS_CAPTURE") {
      const tabId = msg.tabId ?? sender.tab?.id;
      if (!tabId) return Promise.resolve({ success: false, error: "No tab ID" });
      return startCapture(tabId, handleCapturedReplayData).then((success) => ({ success })).catch((err) => ({ success: false, error: String(err) }));
    }
    if (msg.type === "STOP_WS_CAPTURE") {
      const tabId = msg.tabId ?? sender.tab?.id;
      if (!tabId) return Promise.resolve({ success: true });
      return stopCapture(tabId).then(() => ({ success: true }));
    }
    if (msg.type === "GET_WS_CAPTURE_STATUS") {
      const tabId = msg.tabId ?? sender.tab?.id;
      const response = {
        supported: isWebSocketCaptureSupported(),
        active: tabId != null && isCaptureActive(tabId)
      };
      return Promise.resolve(response);
    }
    if (msg.type === "SEND_TO_ANALYZER") {
      const { rawvf, filename, analyzerUrl } = message;
      return handleSendToAnalyzer(rawvf, filename, analyzerUrl, true);
    }
  });
  function handleCapturedReplayData(tabId, data) {
    mlog("Forwarding captured replay data to tab", tabId);
    browser_default.tabs.sendMessage(tabId, {
      type: "WS_REPLAY_DATA",
      data
    }).catch((err) => {
      mwarn("Could not forward replay data to tab", tabId, err);
    });
  }
  function updateBadge(state, tabId) {
    const badgeConfig = {
      idle: { text: "", color: "#6c757d" },
      ready: { text: "\u23F3", color: "#ffc107" },
      recording: { text: "REC", color: "#dc3545" },
      finished: { text: "\u2713", color: "#198754" }
    };
    const config = badgeConfig[state] ?? badgeConfig["idle"];
    browser_default.action.setBadgeText({ text: config.text, tabId });
    browser_default.action.setBadgeBackgroundColor({ color: config.color, tabId });
  }
  var PENDING_REPLAY_KEY = "pendingAnalyzerReplay";
  var analyzerTabId = null;
  function bytesToBase64(bytes) {
    let binary = "";
    const CHUNK = 32768;
    for (let i = 0; i < bytes.length; i += CHUNK) {
      binary += String.fromCharCode.apply(
        null,
        bytes.subarray(i, i + CHUNK)
      );
    }
    return btoa(binary);
  }
  async function handleSendToAnalyzer(data, filename, analyzerUrl, focusTab = true) {
    let bytes;
    if (typeof data === "string") {
      bytes = new TextEncoder().encode(data);
    } else if (data instanceof Uint8Array) {
      bytes = data;
    } else {
      bytes = new Uint8Array(data);
    }
    const dataB64 = bytesToBase64(bytes);
    try {
      let tabId = null;
      let isNewTab = false;
      if (analyzerTabId != null) {
        try {
          const tab = await browser_default.tabs.get(analyzerTabId);
          if (tab.url && tab.url.startsWith(analyzerUrl)) {
            tabId = analyzerTabId;
            mlog("Send to analyzer: reusing tracked tab", tabId);
          } else {
            analyzerTabId = null;
          }
        } catch {
          analyzerTabId = null;
        }
      }
      if (tabId == null) {
        const tabs = await browser_default.tabs.query({ url: analyzerUrl + "*" });
        if (tabs.length > 0 && tabs[0].id != null) {
          tabId = tabs[0].id;
          analyzerTabId = tabId;
          mlog("Send to analyzer: found existing tab via query", tabId);
        }
      }
      if (tabId != null) {
        if (focusTab) {
          await browser_default.tabs.update(tabId, { active: true });
          try {
            const tab = await browser_default.tabs.get(tabId);
            if (tab.windowId != null) {
              await browser_default.windows.update(tab.windowId, { focused: true });
            }
          } catch {
          }
        }
      } else {
        isNewTab = true;
      }
      if (isNewTab) {
        await browser_default.storage.local.set({
          [PENDING_REPLAY_KEY]: { dataB64, filename, timestamp: Date.now() }
        });
        const newTab = await browser_default.tabs.create({ url: analyzerUrl, active: focusTab });
        if (!newTab.id) return { success: false, error: "Failed to create tab" };
        tabId = newTab.id;
        analyzerTabId = tabId;
        await waitForTabLoad(tabId);
        await browser_default.scripting.executeScript({
          target: { tabId },
          func: deliverPendingReplay,
          args: [PENDING_REPLAY_KEY]
        });
      } else {
        await browser_default.scripting.executeScript({
          target: { tabId },
          world: "MAIN",
          func: sendReplayDirect,
          args: [dataB64, filename]
        });
      }
      minfo("Sent replay to analyzer:", filename, isNewTab ? "(new tab)" : "(existing tab)");
      return { success: true };
    } catch (err) {
      mwarn("Send to analyzer failed:", err);
      return { success: false, error: String(err) };
    }
  }
  function waitForTabLoad(tabId) {
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        browser_default.tabs.onUpdated.removeListener(listener);
        reject(new Error("Tab load timeout (30s)"));
      }, 3e4);
      function done() {
        clearTimeout(timeout);
        browser_default.tabs.onUpdated.removeListener(listener);
        resolve();
      }
      function listener(id, changeInfo) {
        if (id === tabId && changeInfo.status === "complete") done();
      }
      browser_default.tabs.onUpdated.addListener(listener);
      browser_default.tabs.get(tabId).then((tab) => {
        if (tab.status === "complete") done();
      }).catch(() => {
        clearTimeout(timeout);
        browser_default.tabs.onUpdated.removeListener(listener);
        reject(new Error("Tab not found"));
      });
    });
  }
  function deliverPendingReplay(storageKey) {
    const TAG = "[MSR Analyzer]";
    const originalTitle = document.title;
    const storageAPI = (() => {
      const g = globalThis;
      if (g.browser?.storage?.local) return g.browser.storage.local;
      if (g.chrome?.storage?.local) return g.chrome.storage.local;
      return null;
    })();
    if (!storageAPI) {
      console.warn(TAG, "No extension storage API available");
      return;
    }
    function storageGet(key) {
      const result = storageAPI.get(key);
      if (result && typeof result.then === "function") return result;
      return new Promise((resolve) => storageAPI.get(key, resolve));
    }
    document.title = "[MSR] Loading replay\u2026";
    storageGet(storageKey).then((result) => {
      const pending = result[storageKey];
      if (!pending?.dataB64 || !pending?.filename) {
        console.warn(TAG, "No pending replay found in storage");
        document.title = originalTitle;
        return;
      }
      const { dataB64, filename } = pending;
      const binary = atob(dataB64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      console.info(TAG, "Delivering replay:", filename, "(" + bytes.length + " bytes)");
      storageAPI.remove(storageKey);
      function send() {
        window.postMessage({
          type: "replay-analyzer-load",
          buffer: bytes.buffer,
          filename
        }, "*");
      }
      let retryInterval = null;
      function cleanup() {
        window.removeEventListener("message", onMessage);
        if (retryInterval != null) clearInterval(retryInterval);
      }
      function onMessage(event) {
        if (event.data?.type === "replay-analyzer-received") {
          console.info(TAG, "Analyzer confirmed receipt");
          document.title = originalTitle;
          cleanup();
        } else if (event.data?.type === "replay-analyzer-ready") {
          console.info(TAG, "Analyzer ready, sending replay");
          send();
        }
      }
      window.addEventListener("message", onMessage);
      send();
      let retryCount = 0;
      const MAX_RETRIES = 60;
      retryInterval = setInterval(() => {
        retryCount++;
        if (retryCount >= MAX_RETRIES) {
          console.warn(TAG, "Gave up after", MAX_RETRIES, "retries");
          document.title = originalTitle;
          cleanup();
          return;
        }
        send();
      }, 500);
    }).catch((err) => {
      console.error(TAG, "Failed to read from storage:", err);
      document.title = originalTitle;
    });
  }
  function sendReplayDirect(dataB64, filename) {
    const TAG = "[MSR Analyzer]";
    const binary = atob(dataB64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    console.info(TAG, "Sending replay:", filename, "(" + bytes.length + " bytes)");
    window.postMessage({
      type: "replay-analyzer-load",
      buffer: bytes.buffer,
      filename
    }, "*");
  }
  initWebSocketCapture();
  var SEND_TO_ANALYZER_MENU_ID = "msr-send-link-to-analyzer";
  function registerContextMenu() {
    browser_default.contextMenus.removeAll().then(() => {
      browser_default.contextMenus.create({
        id: SEND_TO_ANALYZER_MENU_ID,
        title: "Send to Minesweeper Analyzer",
        contexts: ["link"],
        targetUrlPatterns: REPLAY_LINK_PATTERNS
      });
    }).catch((err) => mwarn("Could not register context menu:", err));
  }
  browser_default.runtime.onInstalled.addListener(registerContextMenu);
  registerContextMenu();
  browser_default.contextMenus.onClicked.addListener(async (info) => {
    if (info.menuItemId !== SEND_TO_ANALYZER_MENU_ID) return;
    if (!info.linkUrl) return;
    minfo("Context menu: fetching replay from", info.linkUrl);
    try {
      const response = await fetch(info.linkUrl);
      if (!response.ok) {
        mwarn("Replay fetch failed:", response.status, response.statusText);
        return;
      }
      const buffer = await response.arrayBuffer();
      if (buffer.byteLength === 0) {
        mwarn("Fetched replay is empty");
        return;
      }
      const filename = deriveFilename(info.linkUrl);
      await handleSendToAnalyzer(buffer, filename, ANALYZER_URL, true);
    } catch (err) {
      mwarn("Failed to fetch and send replay:", err);
    }
  });
  function deriveFilename(url) {
    try {
      const u = new URL(url);
      const last = u.pathname.split("/").filter(Boolean).pop();
      if (last) return decodeURIComponent(last);
    } catch {
    }
    return "replay.rawvf";
  }
  browser_default.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes.replayMeta) return;
    const oldMeta = changes.replayMeta.oldValue ?? [];
    const newMeta = changes.replayMeta.newValue ?? [];
    if (newMeta.length <= oldMeta.length) return;
    const oldIds = new Set(oldMeta.map((g) => g.id));
    const newGames = newMeta.filter((g) => !oldIds.has(g.id));
    if (newGames.length === 0) return;
    browser_default.storage.local.get("alwaysAnalyze").then((prefs) => {
      if (prefs.alwaysAnalyze !== true) return;
      for (const game of newGames) {
        const contentKey = `replay_${game.id}`;
        browser_default.storage.local.get(contentKey).then((data) => {
          const rawvf = data[contentKey];
          if (!rawvf) return;
          minfo("Auto-sending to analyzer:", game.filename);
          handleSendToAnalyzer(rawvf, game.filename, ANALYZER_URL, false);
        });
      }
    });
  });
})();
//# sourceMappingURL=index.js.map
